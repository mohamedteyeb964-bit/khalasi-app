import { useState } from "react";
import { Locale, setLocale } from "@/lib/i18n";
import logoImg from "@/assets/khalasi-logo.png";

interface LanguageSelectorProps {
  onComplete: () => void;
}

const languages: { code: Locale; label: string; native: string }[] = [
  { code: "ar", label: "العربية", native: "Arabic" },
  { code: "fr", label: "Français", native: "French" },
  { code: "en", label: "English", native: "English" },
];

const LanguageSelector = ({ onComplete }: LanguageSelectorProps) => {
  const [selected, setSelected] = useState<Locale | null>(null);

  const handleContinue = () => {
    if (!selected) return;
    setLocale(selected);
    document.documentElement.dir = selected === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = selected;
    onComplete();
  };

  return (
    <div className="fixed inset-0 z-[90] flex flex-col items-center justify-center px-6 animate-fade-in gradient-primary">
      {/* Decorative */}
      <div className="absolute top-0 left-0 w-48 h-48 rounded-full bg-white/5 -translate-x-20 -translate-y-20" />
      <div className="absolute bottom-0 right-0 w-64 h-64 rounded-full bg-white/5 translate-x-20 translate-y-20" />

      <div className="relative z-10 flex flex-col items-center w-full max-w-sm">
        <div className="w-24 h-24 mb-5 drop-shadow-2xl">
          <img src={logoImg} alt="خلاصي" className="w-full h-full object-contain" />
        </div>

        <h1 className="text-2xl font-extrabold text-white mb-1">خلاصي — KHALASI</h1>
        <p className="text-white/50 text-sm mb-8">اختر لغتك / Choose your language</p>

        <div className="w-full space-y-3">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => setSelected(lang.code)}
              className={`w-full rounded-2xl p-4 text-center transition-all btn-press ${
                selected === lang.code
                  ? "bg-white/20 border-2 border-white/50 scale-[1.02]"
                  : "bg-white/8 border border-white/15 hover:bg-white/12"
              }`}
              style={{ backdropFilter: "blur(12px)" }}
            >
              <p className="text-white font-bold text-lg">{lang.label}</p>
              <p className="text-white/50 text-xs mt-0.5">{lang.native}</p>
            </button>
          ))}
        </div>

        <button
          onClick={handleContinue}
          disabled={!selected}
          className="w-full mt-8 py-4 rounded-2xl font-bold text-lg transition-all shadow-lg btn-press disabled:opacity-30 bg-white/15 text-white border border-white/20 disabled:bg-transparent"
          style={selected ? {
            background: "hsl(0 0% 100% / 0.2)",
            borderColor: "hsl(0 0% 100% / 0.4)",
          } : undefined}
        >
          {selected === "fr" ? "Continuer" : selected === "en" ? "Continue" : "متابعة"}
        </button>
      </div>
    </div>
  );
};

export default LanguageSelector;
