import { useEffect, useState } from "react";
import logoImg from "@/assets/khalasi-logo.png";

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen = ({ onComplete }: SplashScreenProps) => {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => setFadeOut(true), 1500);
    const timer2 = setTimeout(onComplete, 2000);
    return () => { clearTimeout(timer1); clearTimeout(timer2); };
  }, [onComplete]);

  return (
    <div className={`fixed inset-0 z-[100] flex flex-col items-center justify-center transition-opacity duration-500 ${fadeOut ? "opacity-0" : "opacity-100"}`}
      style={{ background: "linear-gradient(135deg, hsl(180 65% 29%), hsl(192 50% 18%))" }}>
      <div className="absolute top-0 left-0 w-48 h-48 rounded-full bg-white/5 -translate-x-20 -translate-y-20" />
      <div className="absolute bottom-0 right-0 w-64 h-64 rounded-full bg-white/5 translate-x-20 translate-y-20" />

      <div className={`relative z-10 flex flex-col items-center transition-all duration-700 ${fadeOut ? "scale-95" : "scale-100 animate-scale-in"}`}>
        <div className="w-28 h-28 mb-6 drop-shadow-2xl">
          <img src={logoImg} alt="خلاصي" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-3xl font-extrabold text-white mb-1">خلاصي</h1>
        <p className="text-white/60 text-xs font-semibold tracking-[0.3em] uppercase">KHALASI</p>
        <p className="text-white/40 text-[11px] mt-3">النظام المالي للدكان</p>

        <div className="flex gap-1.5 mt-8">
          {[0, 1, 2].map(i => (
            <div key={i} className="w-2 h-2 rounded-full bg-white/40"
              style={{ animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite` }} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;
