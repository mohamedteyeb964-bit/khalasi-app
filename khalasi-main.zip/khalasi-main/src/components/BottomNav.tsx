import { LayoutDashboard, Users, Store, FileText, PlusCircle, Settings, ScanLine, ImageDown } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import { isMerchant } from "@/lib/roles";
import { t } from "@/lib/i18n";
import { canAddMore } from "@/lib/db";
import PaywallScreen from "./PaywallScreen"; // استيراد شاشة الاشتراك

const BottomNav = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const merchantMode = isMerchant();
  const [showPaywall, setShowPaywall] = useState(false); // حالة إظهار شاشة الاشتراك

  const merchantTabs = [
    { path: "/", icon: LayoutDashboard, label: t("nav.dashboard") },
    { path: "/shops", icon: Users, label: t("nav.customers") },
    { path: "/add", icon: PlusCircle, label: t("nav.add"), isCenter: true },
    { path: "/reports", icon: FileText, label: t("nav.reports") },
    { path: "/settings", icon: Settings, label: t("nav.settings") },
  ];

  const customerTabs = [
    { path: "/", icon: LayoutDashboard, label: t("nav.dashboard") },
    { path: "/sync", icon: ScanLine, label: t("nav.scan") },
    { path: "/import", icon: ImageDown, label: t("nav.import"), isCenter: true },
    { path: "/shops", icon: Store, label: t("nav.stores") },
    { path: "/settings", icon: Settings, label: t("nav.settings") },
  ];

  const tabs = merchantMode ? merchantTabs : customerTabs;

  // دالة مخصصة للتعامل مع الضغط على أزرار التنقل
  const handleTabClick = async (path: string, isCenter?: boolean) => {
    // إذا كان الزر المركزي (زر الإضافة)
    if (isCenter) {
      try {
        // فحص ما إذا كان مسموحاً له بالإضافة بناءً على القيود المجانية
        const allowed = await canAddMore();
        if (!allowed) {
          // إذا وصل للحد، نعرض شاشة الدفع ونمنعه من الانتقال
          setShowPaywall(true);
          return;
        }
      } catch (error) {
        console.error("Error checking freemium limits:", error);
      }
    }
    
    // إذا لم يكن الزر المركزي، أو كان مسموحاً له بالإضافة، ينتقل للصفحة بشكل طبيعي
    navigate(path);
  };

  return (
    <>
      {/* نافذة الاشتراك المنبثقة تظهر فوق التطبيق بالكامل عند الحاجة */}
      {showPaywall && (
        <PaywallScreen onClose={() => setShowPaywall(false)} />
      )}

      <nav className="fixed bottom-0 right-0 left-0 z-40 glass border-t border-border/50">
        <div className="flex justify-around items-center h-16 max-w-lg mx-auto">
          {tabs.map((tab) => {
            const isActive = location.pathname === tab.path;
            const isCenter = (tab as any).isCenter;

            return (
              <button
                key={tab.path}
                onClick={() => handleTabClick(tab.path, isCenter)}
                className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all min-w-[50px] btn-press ${
                  isCenter
                    ? "relative -mt-4"
                    : isActive
                      ? "text-primary"
                      : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {isCenter ? (
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg gradient-primary">
                    <tab.icon size={22} className="text-primary-foreground" strokeWidth={2.5} />
                  </div>
                ) : (
                  <tab.icon size={21} strokeWidth={isActive ? 2.5 : 1.8} className="icon-hover" />
                )}
                <span className={`text-[10px] font-semibold ${isCenter ? "mt-0.5" : ""}`}>
                  {tab.label}
                </span>
                {isActive && !isCenter && (
                  <div className="w-4 h-[2px] gradient-primary rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};

export default BottomNav;
