import { Outlet } from "react-router-dom";
import BottomNav from "./BottomNav";
import { getUserRole } from "@/lib/roles";
import { Store, ShoppingBag } from "lucide-react";
import { t } from "@/lib/i18n";
import logoImg from "@/assets/khalasi-logo.png";

const AppLayout = () => {
  const role = getUserRole();

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto relative">
      <header className="sticky top-0 z-40 glass px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <img src={logoImg} alt="خلاصي" className="w-9 h-9 object-contain" />
          <div>
            <h1 className="text-sm font-extrabold text-foreground leading-tight">{t("app.name")}</h1>
            <p className="text-[9px] text-muted-foreground font-semibold tracking-wider">KHALASI</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full glass-card text-[11px] font-bold text-foreground">
          {role === "merchant" ? (
            <><Store size={12} className="text-primary" /> {t("settings.role.merchant.label")}</>
          ) : (
            <><ShoppingBag size={12} className="text-primary" /> {t("settings.role.customer.label")}</>
          )}
        </div>
      </header>
      <main className="pb-20 px-4 pt-4">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
};

export default AppLayout;
