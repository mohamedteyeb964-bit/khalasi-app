import type { Purchase } from "@/lib/store";
import { formatNumber, formatDateTime } from "@/lib/format";
import { isMerchant } from "@/lib/roles";
import { t, getLocale } from "@/lib/i18n";
import { Share2, Download, X, Hash, TrendingUp, Shield, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useRef, useEffect, useState } from "react";
import QRCode from "qrcode";
import { createSignedQRPayload } from "@/lib/hmac";
// تم إصلاح مسار الشعار لضمان ظهوره (تأكد من وجود الصورة في مجلد assets)
import logoImg from "@/assets/khalasi-logo.png";

interface InvoiceCardProps {
  shopName: string;
  shopId: string;
  purchases: Purchase[];
  totalDebt: number;
  onClose: () => void;
  onConfirmSettle: () => void;
}

export function DebtStatusBadge({ purchase }: { purchase: Purchase }) {
  if (purchase.isPaid) {
    return <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[10px] px-1.5 py-0 backdrop-blur-sm">{t("status.paid")}</Badge>;
  }
  if ((purchase.paidAmount || 0) > 0) {
    return <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 text-[10px] px-1.5 py-0 backdrop-blur-sm">{t("status.partial")}</Badge>;
  }
  return <Badge className="bg-rose-500/20 text-rose-300 border-rose-500/30 text-[10px] px-1.5 py-0 backdrop-blur-sm">{t("status.unpaid")}</Badge>;
}

const InvoiceCard = ({ shopName, shopId, purchases, totalDebt, onClose, onConfirmSettle }: InvoiceCardProps) => {
  const invoiceRef = useRef<HTMLDivElement>(null);
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);
  const merchantMode = isMerchant();

  const unpaid = purchases.filter(p => !p.isPaid);
  const paid = purchases.filter(p => p.isPaid);
  const [profit, setProfit] = useState(0);
  const [qrGenerated, setQrGenerated] = useState(false);

  useEffect(() => {
    import("@/lib/store").then(mod => mod.getShopProfit(shopId)).then(setProfit);
  }, [shopId]);

  useEffect(() => {
    const generateQR = async () => {
      if (!qrCanvasRef.current || unpaid.length === 0) return;
      try {
        const payload = await createSignedQRPayload(shopId, shopName, unpaid);
        await QRCode.toCanvas(qrCanvasRef.current, payload, {
          width: 130,
          margin: 2,
          color: { dark: "#0f2e2e", light: "#ffffff" },
        });
        setQrGenerated(true);
      } catch (e) {
        console.error("QR generation failed:", e);
      }
    };
    generateQR();
  }, [shopId, shopName, unpaid]);

  const totalPaid = paid.reduce((s, p) => s + p.amount, 0);
  const totalAll = purchases.reduce((s, p) => s + p.amount, 0);
  const invoiceNumber = `KH-${Date.now().toString(36).toUpperCase()}`;

  const shareWhatsApp = () => {
    let text = `🧾 *${t("invoice.title")} — ${shopName}*\n`;
    text += `📅 ${new Date().toLocaleDateString("en-US")}\n`;
    text += `${"─".repeat(24)}\n\n`;

    purchases.forEach((p, i) => {
      const status = p.isPaid ? "✅" : (p.paidAmount || 0) > 0 ? "🟡" : "🔴";
      text += `${status} ${i + 1}. ${p.note || "---"}\n`;
      text += `   💰 ${formatNumber(p.amount)} ${t("currency")} | 🕐 ${formatDateTime(p.date)}\n`;
      text += `   🔑 ${p.verificationCode}\n\n`;
    });

    text += `${"─".repeat(24)}\n`;
    text += `💰 *${t("invoice.total")}: ${formatNumber(totalDebt)} ${t("currency")}*\n`;
    text += `✅ ${t("dash.paid")}: ${formatNumber(totalPaid)} ${t("currency")}\n\n`;
    text += `_KHALASI — ${t("app.tagline")}_`;

    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const downloadAsImage = async () => {
    if (!invoiceRef.current) return;
    try {
      const { default: html2canvas } = await import("html2canvas");
      // تحسين جودة الصورة عند التحميل
      const canvas = await html2canvas(invoiceRef.current, { 
        scale: 3, 
        backgroundColor: "#0a1919", // لون خلفية الصورة المحملة
        useCORS: true,
        logging: false
      });
      const link = document.createElement("a");
      link.download = `khalasi-invoice-${shopName}-${new Date().toISOString().split("T")[0]}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch {
      shareWhatsApp();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in backdrop-blur-md"
      style={{ backgroundColor: "rgba(10, 25, 25, 0.85)" }} // خلفية الشاشة المعتمة
      onClick={onClose}>
      
      <div className="w-full max-w-sm max-h-[90vh] overflow-y-auto no-scrollbar" onClick={e => e.stopPropagation()}>
        
        {/* الحاوية الرئيسية الزجاجية (Premium Glassmorphism Card) */}
        <div 
          ref={invoiceRef} 
          className="relative rounded-[2rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-white/20"
          style={{ 
            background: "linear-gradient(145deg, rgba(27, 77, 70, 0.9) 0%, rgba(15, 46, 46, 0.95) 100%)",
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)"
          }}
        >
          
          {/* تأثيرات الإضاءة الخلفية (Glowing Orbs) */}
          <div className="absolute -top-20 -left-20 w-64 h-64 bg-emerald-500/20 rounded-full blur-[60px] pointer-events-none" />
          <div className="absolute -bottom-32 -right-32 w-80 h-80 bg-teal-500/10 rounded-full blur-[70px] pointer-events-none" />
          
          {/* خط اللمعان العلوي */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />

          {/* زر الإغلاق */}
          <button onClick={onClose} className="absolute top-4 left-4 w-8 h-8 flex items-center justify-center rounded-full bg-white/10 text-white/80 hover:bg-white/20 hover:text-white z-20 backdrop-blur-md transition-all">
            <X size={18} />
          </button>

          {/* Header Area */}
          <div className="relative z-10 px-6 pt-8 pb-4 text-center border-b border-white/10">
            <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-white/10 p-2 shadow-[0_0_15px_rgba(255,255,255,0.1)] backdrop-blur-md border border-white/20 flex items-center justify-center">
              {/* إذا فشل تحميل الصورة، سيظهر نص بديل أنيق */}
              <img src={logoImg} alt="KHALASI" className="w-full h-full object-contain drop-shadow-md" 
                   onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.parentElement!.innerHTML = '<span class="text-white font-black text-xl">K</span>'; }} />
            </div>
            <h2 className="text-white text-xl font-black tracking-wider drop-shadow-sm">خـلاصي KHALASI</h2>
            <p className="text-emerald-200/80 text-xs font-medium mt-1 uppercase tracking-widest">{t("invoice.title")}</p>
            <p className="text-white/50 text-[10px] mt-1.5 font-mono">{formatDateTime(new Date().toISOString())}</p>
          </div>

          {/* Body Area */}
          <div className="relative z-10 p-6 space-y-5">
            
            {/* Invoice meta */}
            <div className="flex justify-between items-center bg-black/20 rounded-xl p-3 border border-white/5 backdrop-blur-sm">
              <div>
                <span className="text-white/50 text-[10px] uppercase tracking-wider">{t("invoice.number")}</span>
                <p className="font-bold text-white font-mono text-xs mt-0.5" dir="ltr">{invoiceNumber}</p>
              </div>
              <DebtStatusBadge purchase={{ isPaid: totalDebt === 0, paidAmount: totalPaid, amount: totalAll } as Purchase} />
            </div>

            {/* Shop name */}
            <div className="text-center">
              <p className="text-[10px] text-emerald-200/60 uppercase tracking-widest mb-1">{merchantMode ? t("entity.customer") : t("entity.store")}</p>
              <p className="font-black text-white text-2xl drop-shadow-md">{shopName}</p>
            </div>

            {/* Items table */}
            <div className="bg-black/10 rounded-2xl p-4 border border-white/10 backdrop-blur-sm">
              <div className="flex justify-between text-[10px] text-emerald-200/70 font-bold uppercase tracking-wide pb-2 border-b border-white/10">
                <span>{t("invoice.item")}</span>
                <span>{t("invoice.amount")}</span>
              </div>
              
              <div className="space-y-1 mt-2">
                {purchases.map((p, i) => (
                  <div key={p.id} className={`flex items-center justify-between py-2 ${i < purchases.length - 1 ? "border-b border-white/5" : ""}`}>
                    <div className="flex-1 min-w-0">
                      <p className="text-white/90 font-medium text-sm truncate">{p.note || "---"}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="text-[9px] text-white/40 font-mono">{formatDateTime(p.date)}</span>
                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-white/10 text-emerald-200 border border-white/5">
                          <Hash size={7} className="inline -mt-0.5 opacity-50" />{p.verificationCode}
                        </span>
                      </div>
                    </div>
                    <p className={`font-bold text-sm ml-2 ${p.isPaid ? "text-emerald-400 line-through opacity-70" : "text-white"}`}>
                      {formatNumber(p.amount)}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary Highlights */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/5 rounded-xl p-3 border border-white/10 backdrop-blur-sm text-center">
                <span className="text-[10px] text-white/50 block mb-1">{t("invoice.subtotal")}</span>
                <span className="font-bold text-white text-sm">{formatNumber(totalAll)} <span className="text-[9px] text-emerald-200/70">{t("currency")}</span></span>
              </div>
              <div className="bg-emerald-500/10 rounded-xl p-3 border border-emerald-500/20 backdrop-blur-sm text-center">
                <span className="text-[10px] text-emerald-300 block mb-1">{t("dash.paid")}</span>
                <span className="font-bold text-emerald-400 text-sm">{formatNumber(totalPaid)} <span className="text-[9px] text-emerald-200/70">{t("currency")}</span></span>
              </div>
            </div>

            {/* Total Remaining - Big Highlight */}
            <div className="relative overflow-hidden rounded-2xl p-5 text-center bg-gradient-to-br from-rose-500/20 to-red-600/10 border border-rose-500/30 backdrop-blur-md shadow-[0_0_20px_rgba(225,29,72,0.15)]">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 mix-blend-overlay"></div>
              <p className="text-xs text-rose-200/80 font-bold uppercase tracking-widest relative z-10">{t("invoice.remaining")}</p>
              <p className="text-4xl font-black text-rose-400 mt-1 relative z-10 drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
                {formatNumber(totalDebt)} <span className="text-sm font-normal text-rose-200/70">{t("currency")}</span>
              </p>
            </div>

            {/* QR Code Section */}
            {purchases.length > 0 && (
              <div className="flex flex-col items-center pt-2">
                <div className="bg-white p-2.5 rounded-2xl shadow-[0_0_20px_rgba(255,255,255,0.15)] transform transition-transform hover:scale-105 duration-300">
                  <canvas ref={qrCanvasRef} className="rounded-xl" />
                </div>
                {qrGenerated && (
                  <p className="text-[9px] text-emerald-200/60 flex items-center gap-1 mt-3 font-mono">
                    <Shield size={10} className="text-emerald-400" /> موقّعة رقمياً (HMAC-SHA256)
                  </p>
                )}
              </div>
            )}

            {/* Thank you */}
            <p className="text-center text-[11px] text-white/40 italic font-medium pt-2 pb-4">
              {t("invoice.thank.you")} <span className="text-emerald-400">✨</span>
            </p>
          </div>
          
          {/* Sticky Actions Footer */}
          <div className="relative z-20 p-4 bg-black/40 border-t border-white/10 backdrop-blur-xl flex flex-col gap-2.5">
            <div className="flex gap-2">
              <button onClick={onConfirmSettle}
                className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-3 rounded-xl font-bold text-sm shadow-[0_4px_15px_rgba(16,185,129,0.3)] active:scale-[0.98] transition-all">
                {t("invoice.settle")}
              </button>
              <button onClick={shareWhatsApp}
                className="flex items-center justify-center px-5 py-3 rounded-xl font-bold text-sm bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/30 active:scale-[0.98] transition-all">
                <Share2 size={16} />
              </button>
            </div>
            <button onClick={downloadAsImage}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-xs text-white/70 bg-white/5 border border-white/10 hover:bg-white/10 hover:text-white active:scale-[0.98] transition-all">
              <Download size={14} /> حفظ الفاتورة كصورة
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

export default InvoiceCard;
