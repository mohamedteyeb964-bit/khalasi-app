import { useState } from "react";
import { getDeviceId, activatePremium, getWhatsAppActivationUrl } from "@/lib/device";
import { Lock, ShieldCheck, MessageCircle, Copy, Check } from "lucide-react";
import logoImg from "@/assets/khalasi-logo.png";

interface PaywallScreenProps {
  onActivated: () => void;
  onClose: () => void;
}

const PaywallScreen = ({ onActivated, onClose }: PaywallScreenProps) => {
  const [code, setCode] = useState("");
  const [error, setError] = useState(false);
  const [copied, setCopied] = useState(false);
  const deviceId = getDeviceId();

  const handleActivate = () => {
    if (activatePremium(code)) {
      onActivated();
    } else {
      setError(true);
    }
  };

  const copyDeviceId = () => {
    navigator.clipboard.writeText(deviceId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="w-full max-w-sm rounded-2xl overflow-hidden glass-card-elevated glass-shimmer" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="gradient-primary p-5 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 rounded-full bg-white/5 -translate-x-12 -translate-y-12" />
          <Lock size={28} className="text-white mx-auto mb-2" />
          <h2 className="text-white text-lg font-extrabold">الترقية للنسخة الكاملة</h2>
          <p className="text-white/60 text-xs mt-1">افتح جميع الميزات بدون حدود</p>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-sm text-foreground leading-relaxed text-center">
            لإضافة زبائن بلا حدود، يرجى الترقية. حول مبلغ الاشتراك عبر بنكيلي وأرسل لنا صورة التحويل والرمز أدناه على الواتساب.
          </p>

          {/* Device ID */}
          <div className="rounded-xl p-4 text-center space-y-2 bg-primary/8 border border-accent/10">
            <p className="text-[11px] text-muted-foreground font-semibold">معرف جهازك</p>
            <div className="flex items-center justify-center gap-2">
              <p className="text-2xl font-extrabold text-primary tracking-[0.3em] font-mono" dir="ltr">{deviceId}</p>
              <button onClick={copyDeviceId} className="p-1.5 rounded-lg bg-primary/10 text-primary btn-press">
                {copied ? <Check size={14} /> : <Copy size={14} />}
              </button>
            </div>
          </div>

          {/* Activation code */}
          <div>
            <label className="block text-sm font-bold text-foreground mb-2">أدخل كود التفعيل</label>
            <input
              type="text"
              placeholder="أدخل الكود هنا"
              value={code}
              onChange={(e) => { setCode(e.target.value); setError(false); }}
              onKeyDown={(e) => e.key === "Enter" && handleActivate()}
              className="w-full p-3.5 rounded-xl border border-input bg-background text-foreground text-lg font-bold text-center tracking-widest uppercase"
              dir="ltr"
            />
            {error && <p className="text-danger text-[11px] mt-1 font-semibold">كود غير صحيح</p>}
          </div>

          <button
            onClick={handleActivate}
            disabled={!code.trim()}
            className="w-full gradient-primary text-primary-foreground py-3.5 rounded-xl font-bold text-base disabled:opacity-40 btn-press shadow-lg"
          >
            تفعيل
          </button>

          <a
            href={getWhatsAppActivationUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm btn-press bg-success text-success-foreground"
          >
            <MessageCircle size={16} /> تواصل معنا عبر الواتساب
          </a>

          <div className="space-y-1.5 pt-2">
            <p className="text-[11px] text-muted-foreground font-bold">طرق الدفع المتاحة:</p>
            {["Bankily", "السداد", "مصريفي", "كليك"].map(m => (
              <div key={m} className="flex items-center gap-2 text-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-accent inline-block" />
                <span className="text-foreground font-semibold">{m}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaywallScreen;
