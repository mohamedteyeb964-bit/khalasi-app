import { useState, useEffect, useCallback } from "react";
import { isPinSet, setPin, verifyPin, verifyPinRecovery, resetPinWithRecovery } from "@/lib/pin";
import { verifyPinRecoveryKey } from "@/lib/device";
import { restoreAccountFromRecoveryCode } from "@/lib/db"; // استيراد دالة استعادة الحساب
import { Lock, ShieldCheck, Delete, KeyRound, RefreshCcw, AlertTriangle } from "lucide-react";
import { t } from "@/lib/i18n";
import logoImg from "@/assets/khalasi-logo.png";

interface PinLockProps {
  onUnlock: () => void;
}

const PinLock = ({ onUnlock }: PinLockProps) => {
  const [pin, setPinState] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [isSetup, setIsSetup] = useState(false);
  const [step, setStep] = useState<"enter" | "confirm">("enter");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);
  
  // حالات استعادة الـ PIN
  const [showRecovery, setShowRecovery] = useState(false);
  const [recoveryInput, setRecoveryInput] = useState("");
  const [recoveryError, setRecoveryError] = useState(false);
  const [recoverySuccess, setRecoverySuccess] = useState(false);
  const [newPinAfterRecovery, setNewPinAfterRecovery] = useState("");

  // حالات استعادة الحساب بالكامل (الميزة الجديدة)
  const [showAccountRestore, setShowAccountRestore] = useState(false);
  const [accountCodeInput, setAccountCodeInput] = useState("");
  const [accountRestoreError, setAccountRestoreError] = useState("");
  const [isRestoring, setIsRestoring] = useState(false);

  useEffect(() => {
    setIsSetup(!isPinSet());
  }, []);

  const triggerShake = () => {
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  const handleDigit = useCallback((digit: string) => {
    if (recoverySuccess) {
      const next = newPinAfterRecovery + digit;
      setNewPinAfterRecovery(next);
      if (next.length === 4) {
        resetPinWithRecovery(next);
        onUnlock();
      }
      return;
    }

    if (isSetup) {
      if (step === "enter") {
        const next = pin + digit;
        setPinState(next);
        if (next.length === 4) {
          setStep("confirm");
          setPinState("");
          setConfirmPin(next);
        }
      } else {
        const next = pin + digit;
        setPinState(next);
        if (next.length === 4) {
          if (next === confirmPin) {
            setPin(next);
            onUnlock();
          } else {
            setError(t("pin.mismatch"));
            triggerShake();
            setPinState("");
            setStep("enter");
            setConfirmPin("");
          }
        }
      }
    } else {
      const next = pin + digit;
      setPinState(next);
      if (next.length === 4) {
        if (verifyPin(next)) {
          onUnlock();
        } else {
          setError(t("pin.wrong"));
          triggerShake();
          setPinState("");
        }
      }
    }
  }, [pin, step, confirmPin, isSetup, onUnlock, recoverySuccess, newPinAfterRecovery]);

  const handleDelete = () => {
    if (recoverySuccess) {
      setNewPinAfterRecovery(prev => prev.slice(0, -1));
    } else {
      setPinState(prev => prev.slice(0, -1));
    }
    setError("");
  };

  // دالة استعادة الـ PIN
  const handleRecoverySubmit = () => {
    if (verifyPinRecoveryKey(recoveryInput) || verifyPinRecovery(recoveryInput)) {
      setRecoverySuccess(true);
      setRecoveryError(false);
      setShowRecovery(false);
    } else {
      setRecoveryError(true);
    }
  };

  // دالة استعادة الحساب بالكامل (الميزة الجديدة)
  const handleAccountRestoreSubmit = async () => {
    if (!accountCodeInput.trim() || accountCodeInput.length < 5) {
      setAccountRestoreError("الرمز غير صالح. يرجى التأكد من كتابته بشكل صحيح.");
      return;
    }
    
    setIsRestoring(true);
    setAccountRestoreError("");
    
    try {
      const success = await restoreAccountFromRecoveryCode(accountCodeInput);
      if (success) {
        // إذا نجحت الاستعادة، نقوم بفتح التطبيق
        onUnlock();
      } else {
        setAccountRestoreError("لم يتم العثور على حساب بهذا الرمز، أو أنه لا توجد نسخة احتياطية سحابية حالياً.");
      }
    } catch (e) {
      setAccountRestoreError("حدث خطأ أثناء الاتصال بالسيرفر.");
    } finally {
      setIsRestoring(false);
    }
  };

  const currentPin = recoverySuccess ? newPinAfterRecovery : pin;
  const title = recoverySuccess
    ? t("pin.create")
    : isSetup
      ? step === "enter" ? t("pin.create") : t("pin.confirm")
      : t("pin.enter");
  const subtitle = recoverySuccess
    ? t("pin.create.desc")
    : isSetup
      ? step === "enter" ? t("pin.create.desc") : t("pin.confirm.desc")
      : t("pin.enter.desc");

  // شاشة استعادة الحساب بالكامل (الميزة الجديدة)
  if (showAccountRestore) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6" style={{ background: "linear-gradient(135deg, hsl(180 65% 29%), hsl(192 50% 18%))" }}>
        <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center mb-4 shadow-lg border border-white/15">
          <RefreshCcw size={28} className="text-emerald-300" />
        </div>
        <h1 className="text-xl font-extrabold text-white mb-1">استعادة حساب سابق</h1>
        <p className="text-sm text-white/60 mb-6 text-center max-w-xs">أدخل رمز الاسترداد الخاص بك لاسترجاع جميع بياناتك وديونك المحفوظة.</p>
        
        <input 
          type="text" 
          value={accountCodeInput}
          onChange={e => { setAccountCodeInput(e.target.value); setAccountRestoreError(""); }}
          onKeyDown={e => e.key === "Enter" && handleAccountRestoreSubmit()}
          placeholder="مثال: 9AMQ-UNUW-Q64A"
          className="w-64 p-4 rounded-xl border border-white/20 bg-white/10 text-white text-base font-bold text-center tracking-widest uppercase font-mono placeholder:text-white/30 placeholder:tracking-normal focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 outline-none transition-all" 
          dir="ltr" 
        />
        
        {accountRestoreError && (
          <div className="flex items-start gap-1.5 bg-rose-500/20 p-3 rounded-lg border border-rose-500/30 mt-4 max-w-[250px] animate-scale-in">
            <AlertTriangle size={14} className="text-rose-300 shrink-0 mt-0.5" />
            <p className="text-rose-200 text-xs font-medium leading-relaxed">{accountRestoreError}</p>
          </div>
        )}
        
        <button 
          onClick={handleAccountRestoreSubmit} 
          disabled={isRestoring || !accountCodeInput.trim()}
          className="w-64 bg-emerald-500 hover:bg-emerald-600 text-white py-3.5 rounded-xl font-bold mt-5 disabled:opacity-50 transition-colors shadow-lg flex justify-center items-center gap-2"
        >
          {isRestoring ? (
            <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
          ) : (
            <>
              <ShieldCheck size={18} /> استرجاع بياناتي
            </>
          )}
        </button>
        
        <button 
          onClick={() => setShowAccountRestore(false)}
          className="text-white/60 text-sm mt-6 font-medium hover:text-white transition-colors">
          العودة لتسجيل الدخول
        </button>
      </div>
    );
  }

  // شاشة استعادة الـ PIN (القديمة)
  if (showRecovery) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6" style={{ background: "linear-gradient(135deg, hsl(180 65% 29%), hsl(192 50% 18%))" }}>
        <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center mb-4 shadow-lg border border-white/15">
          <KeyRound size={28} className="text-white" />
        </div>
        <h1 className="text-xl font-extrabold text-white mb-1">{t("pin.recovery.title")}</h1>
        <p className="text-sm text-white/60 mb-6 text-center max-w-xs">{t("pin.recovery.enter")}</p>
        
        <input 
          type="text" 
          value={recoveryInput}
          onChange={e => { setRecoveryInput(e.target.value); setRecoveryError(false); }}
          onKeyDown={e => e.key === "Enter" && handleRecoverySubmit()}
          placeholder="XXXX-XXXX-XXXX"
          className="w-64 p-4 rounded-xl border border-white/20 bg-white/10 text-white text-lg font-bold text-center tracking-widest uppercase font-mono outline-none focus:border-white/50 transition-all" 
          dir="ltr" 
        />
        
        {recoveryError && (
          <p className="text-rose-300 text-sm font-semibold mt-3 animate-scale-in">{t("pin.recovery.invalid")}</p>
        )}
        
        <button 
          onClick={handleRecoverySubmit} 
          disabled={!recoveryInput.trim()}
          className="w-64 bg-white/15 hover:bg-white/25 border border-white/25 text-white py-3.5 rounded-xl font-bold mt-5 disabled:opacity-40 transition-colors shadow-lg">
          {t("pin.recovery.reset")}
        </button>
        
        <button 
          onClick={() => setShowRecovery(false)}
          className="text-white/60 text-sm mt-6 font-medium hover:text-white transition-colors">
          {t("btn.back")}
        </button>
      </div>
    );
  }

  // الشاشة الرئيسية للـ PIN
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6" style={{ background: "linear-gradient(135deg, hsl(180 65% 29%), hsl(192 50% 18%))" }}>
      <div className="w-20 h-20 mb-4 animate-slide-up">
        <img src={logoImg} alt="خلاصي" className="w-full h-full object-contain drop-shadow-lg" />
      </div>
      
      <h1 className="text-xl font-extrabold text-white mb-1 animate-slide-up">{title}</h1>
      <p className="text-sm text-white/60 mb-6 animate-slide-up">{subtitle}</p>

      {/* PIN Dots */}
      <div className={`flex gap-4 mb-2 ${shake ? "animate-shake" : ""}`}>
        {[0, 1, 2, 3].map(i => (
          <div key={i}
            className={`w-4 h-4 rounded-full transition-all duration-200 ${
              i < currentPin.length ? "bg-white scale-110 shadow-lg" : "bg-white/20 border-2 border-white/30"
            }`} />
        ))}
      </div>

      {error && <p className="text-rose-300 text-sm font-semibold mt-4 mb-2 animate-scale-in">{error}</p>}

      {/* Keypad */}
      <div className="grid grid-cols-3 gap-3 mt-6 w-64">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "del"].map((key) => {
          if (key === "") return <div key="empty" />;
          if (key === "del") {
            return (
              <button key="del" onClick={handleDelete}
                className="w-20 h-14 rounded-2xl flex items-center justify-center text-white/50 hover:text-white transition-colors active:scale-95">
                <Delete size={22} />
              </button>
            );
          }
          return (
            <button key={key} onClick={() => handleDigit(key)}
              className="w-20 h-14 rounded-2xl bg-white/10 border border-white/10 text-xl font-bold text-white hover:bg-white/20 active:scale-95 transition-all shadow-sm">
              {key}
            </button>
          );
        })}
      </div>

      {isSetup && !recoverySuccess && (
        <p className="text-[11px] text-white/40 mt-8 text-center max-w-xs">{t("pin.security.note")}</p>
      )}

      {/* منطقة الأزرار السفلية (الجديدة) */}
      {!isSetup && !recoverySuccess && (
        <div className="flex flex-col items-center gap-4 mt-8 w-full max-w-[250px]">
          {/* زر نسيت الـ PIN */}
          <button 
            onClick={() => setShowRecovery(true)}
            className="text-white/60 text-xs font-semibold hover:text-white transition-colors w-full text-center">
            {t("pin.forgot")}
          </button>
          
          <div className="h-[1px] w-full bg-white/10" />
          
          {/* زر استعادة الحساب الجديد */}
          <button 
            onClick={() => setShowAccountRestore(true)}
            className="flex items-center justify-center gap-1.5 w-full bg-white/5 hover:bg-white/10 border border-white/10 text-white/90 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm">
            <RefreshCcw size={14} className="text-emerald-400" />
            استعادة حساب سابق
          </button>
        </div>
      )}
    </div>
  );
};

export default PinLock;
