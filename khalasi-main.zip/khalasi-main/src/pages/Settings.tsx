import { useState } from "react";
import { getUserRole } from "@/lib/roles";
import { getDeviceId, isPremium, getPremiumDaysRemaining, getWhatsAppActivationUrl, activatePremium } from "@/lib/device";
import { isPinSet, lockSession, getRecoveryCode } from "@/lib/pin";
import { getLocale, setLocale, t, type Locale } from "@/lib/i18n";
import { useNavigate } from "react-router-dom";
import * as db from "@/lib/db";
import {
  Settings as SettingsIcon, Shield, Crown, Download, Upload, Key,
  Copy, Check, CheckCircle, AlertTriangle, Store, ShoppingBag,
  Globe, ChevronLeft, Lock, Share2, MessageCircle, Fingerprint, Calendar
} from "lucide-react";

const Settings = () => {
  const navigate = useNavigate();
  const role = getUserRole();
  const deviceId = getDeviceId();
  const premium = isPremium();
  const daysLeft = getPremiumDaysRemaining();
  const [copied, setCopied] = useState(false);
  const [backupMsg, setBackupMsg] = useState("");
  const [showRecovery, setShowRecovery] = useState(false);
  const [showActivation, setShowActivation] = useState(false);
  const [activationCode, setActivationCode] = useState("");
  const [activationError, setActivationError] = useState(false);
  const [locale, setLocaleState] = useState(getLocale());
  const recoveryCode = getRecoveryCode();

  const merchantMode = role === "merchant";

  const copyDeviceId = () => {
    navigator.clipboard.writeText(deviceId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleActivate = () => {
    if (activatePremium(activationCode)) {
      setShowActivation(false);
      setActivationError(false);
      setActivationCode("");
      window.location.reload();
    } else {
      setActivationError(true);
    }
  };

  const switchLocale = (l: Locale) => {
    setLocale(l);
    setLocaleState(l);
    document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = l;
  };

  const handleExportBackup = async () => {
    if (!premium) { setShowActivation(true); return; }
    const data = await db.exportBackup();
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Khalasi_Backup_${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setBackupMsg(t("settings.backup.export"));
    setTimeout(() => setBackupMsg(""), 3000);
  };

  const handleShareBackup = async () => {
    if (!premium) { setShowActivation(true); return; }
    const data = await db.exportBackup();
    const text = `📦 ${t("backup.whatsapp.title")}\n📅 ${new Date().toLocaleDateString("en-US")}\n\n${t("backup.whatsapp.paste")}\n\n${data.slice(0, 500)}...`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const handleImportBackup = () => {
    if (!premium) { setShowActivation(true); return; }
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const result = await db.importBackup(ev.target?.result as string);
        if (result) {
          setBackupMsg(t("settings.backup.success"));
          setTimeout(() => window.location.reload(), 1500);
        } else {
          setBackupMsg(t("settings.backup.fail"));
          setTimeout(() => setBackupMsg(""), 3000);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const handleLock = () => {
    lockSession();
    window.location.reload();
  };

  return (
    <div className="space-y-4 animate-slide-up">
      <h1 className="text-lg font-extrabold text-foreground flex items-center gap-2">
        <SettingsIcon size={20} className="text-primary" /> {t("settings.title")}
      </h1>

      {/* Role Card */}
      <div className="glass-card-elevated rounded-2xl p-5">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center shadow-sm">
            {merchantMode ? <Store size={24} className="text-primary-foreground" /> : <ShoppingBag size={24} className="text-primary-foreground" />}
          </div>
          <div className="flex-1">
            <p className="font-extrabold text-foreground">{merchantMode ? t("settings.role.merchant") : t("settings.role.customer")}</p>
            <p className="text-[11px] text-muted-foreground">{merchantMode ? t("settings.role.merchant.desc") : t("settings.role.customer.desc")}</p>
          </div>
          {premium && (
            <div className="flex flex-col items-center gap-0.5">
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-primary/15 border border-primary/20">
                <Crown size={12} className="text-primary" />
                <span className="text-[10px] font-bold text-primary">{t("settings.premium.status")}</span>
              </div>
              <div className="flex items-center gap-1 text-[9px] text-muted-foreground">
                <Calendar size={8} />
                <span>{daysLeft} {t("settings.premium.days")}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Device ID */}
      <div className="glass-card rounded-2xl p-4 flex items-center gap-3">
        <Fingerprint size={18} className="text-primary shrink-0" />
        <div className="flex-1">
          <p className="text-[10px] text-muted-foreground font-semibold">{t("settings.device")}</p>
          <p className="text-lg font-extrabold text-foreground font-mono tracking-[0.2em]" dir="ltr">{deviceId}</p>
        </div>
        <button onClick={copyDeviceId} className="p-2 rounded-xl bg-primary/10 text-primary btn-press">
          {copied ? <Check size={16} /> : <Copy size={16} />}
        </button>
      </div>

      {/* Language Selector */}
      <div className="glass-card rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Globe size={16} className="text-primary" />
          <p className="font-bold text-foreground text-sm">{t("settings.language")}</p>
        </div>
        <div className="flex gap-2">
          {([
            { code: "ar" as Locale, label: "العربية", flag: "🇲🇷" },
            { code: "fr" as Locale, label: "Français", flag: "🇫🇷" },
            { code: "en" as Locale, label: "English", flag: "🇬🇧" },
          ]).map(lang => (
            <button key={lang.code} onClick={() => switchLocale(lang.code)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-semibold text-sm transition-all btn-press ${
                locale === lang.code ? "gradient-primary text-primary-foreground shadow-sm" : "bg-secondary text-secondary-foreground"
              }`}>
              <span>{lang.flag}</span> {lang.label}
            </button>
          ))}
        </div>
      </div>

      {/* Recovery Code */}
      {recoveryCode && (
        <div className="glass-card rounded-2xl p-4 border border-warning/15">
          <button onClick={() => setShowRecovery(!showRecovery)} className="w-full flex items-center gap-3 text-right">
            <Key size={18} className="text-warning shrink-0" />
            <div className="flex-1">
              <p className="font-bold text-foreground text-sm">{t("settings.recovery")}</p>
              <p className="text-[10px] text-muted-foreground">{t("settings.recovery.save")}</p>
            </div>
            <ChevronLeft size={16} className={`text-muted-foreground transition-transform ${showRecovery ? "rotate-90" : ""}`} />
          </button>
          {showRecovery && (
            <div className="mt-3 p-3 rounded-xl bg-warning/5 border border-warning/10 animate-scale-in">
              <p className="text-center font-mono font-extrabold text-lg tracking-[0.2em] text-foreground" dir="ltr">{recoveryCode}</p>
              <p className="text-[10px] text-center text-warning mt-2 font-semibold flex items-center justify-center gap-1">
                <AlertTriangle size={10} /> {t("settings.recovery.warn")}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Premium / Upgrade */}
      {!premium ? (
        <div className="glass-card-elevated rounded-2xl p-4 space-y-3 border border-primary/15">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl gradient-primary flex items-center justify-center shadow-sm">
              <Crown size={18} className="text-primary-foreground" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-foreground text-sm">{t("settings.upgrade")}</p>
              <p className="text-[10px] text-muted-foreground">100 {t("reports.transactions")} {t("settings.premium.free")}</p>
            </div>
          </div>

          {showActivation && (
            <div className="space-y-3 animate-scale-in">
              <input type="text" placeholder={t("activation.code.label")} value={activationCode}
                onChange={e => { setActivationCode(e.target.value); setActivationError(false); }}
                onKeyDown={e => e.key === "Enter" && handleActivate()}
                className="w-full p-3.5 rounded-xl border border-input bg-card text-foreground text-lg font-bold text-center tracking-widest uppercase" dir="ltr" />
              {activationError && <p className="text-danger text-[11px] font-semibold">{t("activation.invalid")}</p>}
              <button onClick={handleActivate} disabled={!activationCode.trim()}
                className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold disabled:opacity-40 btn-press shadow-sm">
                {t("activation.activate")}
              </button>
            </div>
          )}

          {!showActivation && (
            <button onClick={() => setShowActivation(true)}
              className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold btn-press shadow-sm">
              {t("activation.title")}
            </button>
          )}

          <a href={getWhatsAppActivationUrl()} target="_blank" rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm btn-press bg-success text-success-foreground">
            <MessageCircle size={16} /> {t("activation.whatsapp")}
          </a>
        </div>
      ) : (
        <div className="glass-card rounded-2xl p-4 flex items-center gap-3 border border-primary/15">
          <Crown size={18} className="text-primary" />
          <div className="flex-1">
            <p className="font-bold text-foreground text-sm">{t("settings.premium")} ✓</p>
            <p className="text-[10px] text-muted-foreground">{daysLeft} {t("settings.premium.days")}</p>
          </div>
        </div>
      )}

      {/* Backup */}
      <div className="glass-card rounded-2xl p-4 space-y-3">
        <h2 className="font-bold text-foreground text-sm flex items-center gap-2">
          <Download size={16} className="text-primary" /> {t("settings.backup")}
          {!premium && <span className="text-[9px] bg-primary/15 text-primary px-1.5 py-0.5 rounded-full font-bold">Premium</span>}
        </h2>
        {backupMsg && (
          <div className="bg-success/10 text-success rounded-xl p-2.5 text-sm font-semibold flex items-center gap-1.5">
            <CheckCircle size={14} /> {backupMsg}
          </div>
        )}
        <div className="flex gap-2">
          <button onClick={handleExportBackup}
            className="flex-1 flex items-center justify-center gap-1.5 gradient-primary text-primary-foreground py-2.5 rounded-xl font-semibold text-sm btn-press shadow-sm">
            <Download size={15} /> {t("settings.backup.export")}
          </button>
          <button onClick={handleImportBackup}
            className="flex-1 flex items-center justify-center gap-1.5 bg-secondary text-secondary-foreground py-2.5 rounded-xl font-semibold text-sm btn-press">
            <Upload size={15} /> {t("settings.backup.import")}
          </button>
        </div>
        {premium && (
          <button onClick={handleShareBackup}
            className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-semibold text-sm border border-success/20 text-success btn-press hover:bg-success/5 transition-colors">
            <Share2 size={14} /> {t("settings.backup.share")}
          </button>
        )}
      </div>

      {/* Lock */}
      {isPinSet() && (
        <button onClick={handleLock}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-danger/20 text-danger font-semibold text-sm btn-press hover:bg-danger/5 transition-colors">
          <Shield size={16} /> {t("settings.pin.lock")}
        </button>
      )}
    </div>
  );
};

export default Settings;
