import { useState } from "react";
import { Shield, Key, Lock, Copy, CheckCircle } from "lucide-react";

const KHALASI_CORE = {
  salt: [0x5A, 0x3B, 0x9F, 0x1C, 0x88, 0x4D],
  matrix: [
    ['X','K','9','A','2','M'], ['7','Z','L','P','3','V'],
    ['B','4','C','D','5','E'], ['F','6','G','H','8','J'],
    ['Q','R','S','T','U','W'], ['Y','N','1','0','O','I']
  ],
  complexHash: function(inputStr: string): string {
    let hashVector = 0x811C9DC5;
    let output = "";
    for (let i = 0; i < inputStr.length; i++) {
      const charCode = inputStr.charCodeAt(i);
      hashVector ^= (charCode + this.salt[i % this.salt.length]);
      hashVector += (hashVector << 1) + (hashVector << 4) + (hashVector << 7) + (hashVector << 8) + (hashVector << 24);
      hashVector = hashVector | 0;
      const row = Math.abs(hashVector % 6);
      const col = Math.abs((hashVector >> 3) % 6);
      output += this.matrix[row][col];
    }
    return output.substring(0, 3) + "-" + output.substring(3, 6);
  }
};

function generatePinRecovery(deviceId: string): string {
  const reversed = deviceId.split("").reverse().join("");
  const hexLen = deviceId.length.toString(16).toUpperCase();
  return reversed + "KH" + hexLen;
}

const AdminPortal = () => {
  const [deviceId, setDeviceId] = useState("");
  const [activationKey, setActivationKey] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [copied, setCopied] = useState<string | null>(null);

  const handleGenerate = () => {
    const id = deviceId.toUpperCase().trim();
    if (id.length !== 6) return;
    setActivationKey(KHALASI_CORE.complexHash(id));
    setRecoveryCode(generatePinRecovery(id));
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl gradient-primary mx-auto flex items-center justify-center">
            <Shield size={28} className="text-accent" />
          </div>
          <h1 className="text-xl font-extrabold text-foreground">KHALASI-256 Admin Portal</h1>
          <p className="text-xs text-muted-foreground">Secure Activation & Recovery Generator</p>
        </div>

        <div className="glass-card-elevated rounded-2xl p-5 space-y-4">
          <label className="block text-sm font-bold text-foreground">Device ID (6 characters)</label>
          <input
            type="text"
            maxLength={6}
            value={deviceId}
            onChange={e => setDeviceId(e.target.value.toUpperCase())}
            placeholder="e.g. QZXZWW"
            className="w-full p-3 rounded-xl border border-input bg-background text-foreground text-center text-lg font-mono tracking-[0.3em] uppercase"
            dir="ltr"
          />
          <button
            onClick={handleGenerate}
            disabled={deviceId.trim().length !== 6}
            className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold disabled:opacity-40 btn-press"
          >
            Generate Keys
          </button>
        </div>

        {activationKey && (
          <div className="space-y-3 animate-slide-up">
            <div className="glass-card-elevated rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-2 text-accent">
                <Key size={16} />
                <span className="text-sm font-bold">Activation Key</span>
              </div>
              <div className="flex items-center justify-between bg-background rounded-xl p-3">
                <span className="font-mono text-lg font-bold text-foreground tracking-widest" dir="ltr">{activationKey}</span>
                <button onClick={() => copyToClipboard(activationKey, "activation")} className="text-muted-foreground hover:text-accent transition-colors">
                  {copied === "activation" ? <CheckCircle size={18} className="text-success" /> : <Copy size={18} />}
                </button>
              </div>
            </div>

            <div className="glass-card-elevated rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-2 text-accent">
                <Lock size={16} />
                <span className="text-sm font-bold">PIN Recovery Code</span>
              </div>
              <div className="flex items-center justify-between bg-background rounded-xl p-3">
                <span className="font-mono text-lg font-bold text-foreground tracking-widest" dir="ltr">{recoveryCode}</span>
                <button onClick={() => copyToClipboard(recoveryCode, "recovery")} className="text-muted-foreground hover:text-accent transition-colors">
                  {copied === "recovery" ? <CheckCircle size={18} className="text-success" /> : <Copy size={18} />}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPortal;
