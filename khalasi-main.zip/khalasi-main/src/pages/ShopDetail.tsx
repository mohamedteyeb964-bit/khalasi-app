import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import * as db from "@/lib/db";
import { formatNumber, formatCurrency, formatDateTime } from "@/lib/format";
import { isMerchant, isCustomer } from "@/lib/roles";
import { createSignedQRPayload } from "@/lib/hmac";
import { ArrowRight, Plus, ShoppingBag, X, Search, Trash2, Pencil, Share2, Camera, Shield, Lock, Hash, QrCode, ShieldCheck, Copy, ImageIcon, Banknote, FileText, TrendingUp, CreditCard, Users } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import InvoiceCard, { DebtStatusBadge } from "@/components/InvoiceCard";
import QRCode from "qrcode";
import { t } from "@/lib/i18n";

const ShopDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [shopName, setShopName] = useState("");
  const [purchases, setPurchases] = useState<db.Purchase[]>([]);
  const [debt, setDebt] = useState(0);
  const [profit, setProfit] = useState(0);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [amount, setAmount] = useState("");
  const [costPrice, setCostPrice] = useState("");
  const [note, setNote] = useState("");
  const [photo, setPhoto] = useState<string | undefined>();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "unpaid" | "paid">("all");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editAmount, setEditAmount] = useState("");
  const [editNote, setEditNote] = useState("");
  const [editPin, setEditPin] = useState("");
  const [editPinError, setEditPinError] = useState(false);
  const [showInvoice, setShowInvoice] = useState(false);
  const [showPinSetup, setShowPinSetup] = useState(false);
  const [newPin, setNewPin] = useState("");
  const [viewingPhoto, setViewingPhoto] = useState<string | null>(null);
  const [showSyncCode, setShowSyncCode] = useState(false);
  const [syncCode, setSyncCode] = useState("");
  const [syncCopied, setSyncCopied] = useState(false);
  const [showCompare, setShowCompare] = useState(false);
  const [comparePhoto, setComparePhoto] = useState<string | null>(null);
  const [hasPin, setHasPin] = useState(false);
  const [syncedIds, setSyncedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [showPayment, setShowPayment] = useState<string | null>(null);
  const [payAmount, setPayAmount] = useState("");
  const [payMethod, setPayMethod] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const compareInputRef = useRef<HTMLInputElement>(null);

  const merchantMode = isMerchant();
  const customerMode = isCustomer();

  const load = async () => {
    if (!id) return;
    const allShops = await db.getShops();
    const shop = allShops.find(s => s.id === id);
    if (!shop) { navigate("/shops"); return; }
    setShopName(shop.name);
    const shopPurchases = await db.getShopPurchases(id);
    setPurchases(shopPurchases.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setDebt(await db.getShopDebt(id));
    setProfit(await db.getShopProfit(id));
    const pin = await db.getShopPin(id);
    setHasPin(!!pin);
    const syncedSet = new Set<string>();
    for (const p of shopPurchases) {
      if (await db.isSynced(p.id)) syncedSet.add(p.id);
    }
    setSyncedIds(syncedSet);
    setLoading(false);
  };

  useEffect(() => { load(); }, [id]);

  const handleSettle = () => { if (!id) return; setShowInvoice(true); };
  const confirmSettle = async () => { if (!id) return; await db.settleShopDebt(id); setShowInvoice(false); load(); };

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setPhoto(reader.result as string);
    reader.readAsDataURL(file);
  };
  const handleComparePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setComparePhoto(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleQuickAdd = async () => {
    if (!id || !amount || isNaN(Number(amount)) || Number(amount) <= 0) return;
    const cp = costPrice && !isNaN(Number(costPrice)) ? Number(costPrice) : undefined;
    const p = await db.addPurchase(id, Number(amount), note.trim(), photo, cp);
    setAmount(""); setCostPrice(""); setNote(""); setPhoto(undefined); setShowQuickAdd(false);
    load();
    alert(`${t("shop.register.success")}\n${t("shop.verify.code")} ${p.verificationCode}`);
  };

  const handleDelete = async (purchaseId: string) => {
    if (confirm(t("shop.delete.confirm"))) { await db.deletePurchase(purchaseId); load(); }
  };

  const startEdit = (p: db.Purchase) => {
    setEditingId(p.id); setEditAmount(p.amount.toString()); setEditNote(p.note); setEditPin(""); setEditPinError(false);
  };

  const saveEdit = async () => {
    if (!editingId || !editAmount || !id) return;
    if (hasPin) {
      const valid = await db.verifyMerchantPin(id, editPin);
      if (!valid) { setEditPinError(true); return; }
    }
    await db.updatePurchase(editingId, { amount: Number(editAmount), note: editNote });
    setEditingId(null); setEditPin(""); load();
  };

  const handleSetPin = async () => {
    if (!id || !newPin.trim()) return;
    await db.setMerchantPin(id, newPin.trim());
    setShowPinSetup(false); setNewPin("");
    load();
  };

  const handlePartialPayment = async (purchaseId: string) => {
    if (!payAmount || isNaN(Number(payAmount)) || Number(payAmount) <= 0) return;
    await db.makePartialPayment(purchaseId, Number(payAmount));
    setShowPayment(null); setPayAmount(""); setPayMethod("");
    load();
  };

  const [syncQrDataUrl, setSyncQrDataUrl] = useState("");

  const handleGenerateSyncCode = async () => {
    if (!id) return;
    const allShops = await db.getShops();
    const shop = allShops.find(s => s.id === id);
    if (!shop) return;
    const unpaidItems = purchases.filter(p => !p.isPaid);
    const payload = await createSignedQRPayload(shop.id, shop.name, unpaidItems);
    setSyncCode(payload);
    try {
      const dataUrl = await QRCode.toDataURL(payload, { width: 280, margin: 2, color: { dark: "#1a4a4a", light: "#ffffff" } });
      setSyncQrDataUrl(dataUrl);
    } catch {}
    setShowSyncCode(true);
  };

  const copySyncCode = () => { navigator.clipboard.writeText(syncCode); setSyncCopied(true); setTimeout(() => setSyncCopied(false), 2000); };
  const shareSyncCodeWhatsApp = () => {
    const text = `🔗 *${t("shop.sync.whatsapp.title")} — ${shopName}*\n\n${t("shop.sync.whatsapp.desc")}\n\n${syncCode}\n\n_${t("app.name")} — ${t("app.tagline")}_`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const shareWhatsApp = () => {
    const unpaid = purchases.filter(p => !p.isPaid);
    let text = `📋 *${t("shop.whatsapp.title")} — ${shopName}*\n📅 ${formatDateTime(new Date().toISOString())}\n\n`;
    unpaid.forEach((p, i) => {
      text += `${i + 1}. ${p.note || t("reports.no.note")} — ${formatNumber(p.amount)} ${t("currency")} [${p.verificationCode}]\n   🕐 ${formatDateTime(p.date)}\n`;
    });
    text += `\n💰 *${t("shop.whatsapp.total")} ${formatNumber(debt)} ${t("currency")}*\n\n_${t("app.name")}_`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const unpaidPurchases = purchases.filter(p => !p.isPaid);
  const unpaidCount = unpaidPurchases.length;

  const filtered = purchases.filter(p => {
    if (filterStatus === "unpaid" && p.isPaid) return false;
    if (filterStatus === "paid" && !p.isPaid) return false;
    if (searchQuery && !(p.note || "").includes(searchQuery)) return false;
    return true;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-slide-up">
      <button onClick={() => navigate("/shops")} className="flex items-center gap-1 text-primary font-semibold text-sm btn-press">
        <ArrowRight size={15} /> {t("btn.back")}
      </button>

      {/* Debt Summary Hero */}
      <div className="gradient-primary rounded-2xl p-5 text-primary-foreground relative overflow-hidden shadow-lg">
        <div className="absolute top-0 left-0 w-36 h-36 rounded-full bg-white/5 -translate-x-12 -translate-y-12" />
        <div className="absolute bottom-0 right-0 w-28 h-28 rounded-full bg-white/5 translate-x-10 translate-y-10" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <Banknote size={16} className="opacity-70" />
            <p className="text-xs opacity-70 font-semibold">{shopName}</p>
            {customerMode && (
              <span className="text-[10px] bg-white/15 px-2 py-0.5 rounded-full font-bold mr-auto">{t("shop.customer.mode")}</span>
            )}
          </div>
          <p className="text-3xl font-extrabold">
            {formatNumber(debt)}
            <span className="text-sm font-normal mr-1 opacity-70">{t("currency")}</span>
          </p>
          <p className="text-[11px] opacity-60 mt-1">
            {debt > 0 ? `${unpaidCount} ${t("shop.debt.summary")}` : t("shop.no.debt")}
          </p>
          {merchantMode && profit > 0 && (
            <div className="flex items-center gap-1.5 mt-1.5 text-[11px] opacity-80">
              <TrendingUp size={11} /> {t("shop.profit")} {formatNumber(profit)} {t("currency")}
            </div>
          )}
          <div className="flex gap-2 mt-4 flex-wrap">
            {debt > 0 && (
              <button onClick={handleSettle} className="flex items-center gap-1.5 glass-dark text-primary-foreground px-3.5 py-2 rounded-xl font-bold text-xs btn-press">
                <FileText size={14} /> {t("shop.invoice")}
              </button>
            )}
            <button onClick={() => setShowQuickAdd(true)} className="flex items-center gap-1.5 glass-dark text-primary-foreground px-3.5 py-2 rounded-xl font-bold text-xs btn-press">
              <Plus size={14} /> {t("btn.add")}
            </button>
            {debt > 0 && (
              <button onClick={shareWhatsApp} className="flex items-center gap-1.5 glass-dark text-primary-foreground px-3.5 py-2 rounded-xl font-bold text-xs btn-press">
                <Share2 size={14} /> {t("shop.share")}
              </button>
            )}
            {merchantMode && (
              <>
                <button onClick={() => setShowPinSetup(true)} className="flex items-center gap-1.5 glass-dark text-primary-foreground px-3 py-2 rounded-xl font-bold text-xs btn-press">
                  <Shield size={13} /> {hasPin ? t("shop.pin") : "PIN"}
                </button>
                {debt > 0 && (
                  <button onClick={handleGenerateSyncCode} className="flex items-center gap-1.5 glass-dark text-primary-foreground px-3 py-2 rounded-xl font-bold text-xs btn-press">
                    <QrCode size={13} /> {t("shop.link")}
                  </button>
                )}
              </>
            )}
            {customerMode && (
              <button onClick={() => setShowCompare(true)} className="flex items-center gap-1.5 glass-dark text-primary-foreground px-3 py-2 rounded-xl font-bold text-xs btn-press">
                <ImageIcon size={13} /> {t("shop.compare")}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Invoice Modal */}
      {showInvoice && id && (
        <InvoiceCard shopName={shopName} shopId={id} purchases={purchases} totalDebt={debt}
          onClose={() => setShowInvoice(false)} onConfirmSettle={confirmSettle} />
      )}

      {/* Sync Code Modal */}
      {showSyncCode && (
        <div className="glass-card-elevated rounded-2xl p-5 space-y-3 border border-primary/15 animate-scale-in">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-foreground flex items-center gap-2 text-sm"><QrCode size={16} className="text-primary" /> {t("sync.encrypted.code")}</h3>
            <button onClick={() => setShowSyncCode(false)} className="text-muted-foreground icon-hover"><X size={17} /></button>
          </div>
          <p className="text-[11px] text-muted-foreground">{t("sync.share.desc")}</p>
          {syncQrDataUrl && (
            <div className="flex justify-center py-2">
              <img src={syncQrDataUrl} alt="QR Code" className="rounded-xl shadow-sm" style={{ width: 200 }} />
            </div>
          )}
          <div className="bg-muted rounded-xl p-3 max-h-20 overflow-y-auto">
            <p className="text-[9px] font-mono text-foreground break-all leading-relaxed" dir="ltr">{syncCode.slice(0, 200)}...</p>
          </div>
          <div className="flex gap-2">
            <button onClick={copySyncCode} className="flex-1 flex items-center justify-center gap-1.5 gradient-primary text-primary-foreground py-2.5 rounded-xl font-semibold text-sm btn-press">
              <Copy size={13} /> {syncCopied ? t("sync.copied") : t("sync.copy")}
            </button>
            <button onClick={shareSyncCodeWhatsApp} className="flex-1 flex items-center justify-center gap-1.5 bg-success text-success-foreground py-2.5 rounded-xl font-semibold text-sm btn-press">
              <Share2 size={13} /> WhatsApp
            </button>
          </div>
        </div>
      )}

      {/* Compare Account (Customer) */}
      {showCompare && (
        <div className="glass-card-elevated rounded-2xl p-5 space-y-3 border border-primary/15 animate-scale-in">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-foreground flex items-center gap-2 text-sm"><ImageIcon size={16} className="text-primary" /> {t("shop.compare.title")}</h3>
            <button onClick={() => { setShowCompare(false); setComparePhoto(null); }} className="text-muted-foreground"><X size={17} /></button>
          </div>
          <p className="text-[11px] text-muted-foreground">{t("shop.compare.desc")}</p>
          <input ref={compareInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleComparePhoto} />
          {comparePhoto ? (
            <div className="space-y-3">
              <div className="relative">
                <img src={comparePhoto} alt="" className="w-full h-48 object-contain rounded-xl border border-border bg-muted" />
                <button onClick={() => setComparePhoto(null)} className="absolute top-1 left-1 bg-danger text-danger-foreground rounded-full p-1"><X size={13} /></button>
              </div>
              <div className="bg-primary/5 rounded-xl p-3">
                <p className="text-[11px] font-bold text-foreground mb-2">{t("shop.compare.records")} ({unpaidCount} {t("reports.transactions")}):</p>
                {unpaidPurchases.slice(0, 5).map(p => (
                  <div key={p.id} className="flex justify-between text-[11px] py-0.5">
                    <span className="text-muted-foreground">{p.note || t("reports.no.note")} [{p.verificationCode}]</span>
                    <span className="font-bold text-foreground">{formatNumber(p.amount)}</span>
                  </div>
                ))}
                {unpaidPurchases.length > 5 && <p className="text-[10px] text-muted-foreground mt-1">{t("shop.compare.more").replace("{count}", (unpaidPurchases.length - 5).toString())}</p>}
                <div className="border-t border-border mt-2 pt-1 flex justify-between">
                  <span className="text-[11px] font-bold text-foreground">{t("shop.compare.total")}</span>
                  <span className="text-sm font-extrabold text-danger">{formatNumber(debt)} {t("currency")}</span>
                </div>
              </div>
            </div>
          ) : (
            <button onClick={() => compareInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 p-4 rounded-xl border-2 border-dashed border-input text-muted-foreground hover:border-primary hover:text-primary transition-colors text-sm btn-press">
              <Camera size={18} /> {t("camera.compare")}
            </button>
          )}
        </div>
      )}

      {/* PIN Setup */}
      {showPinSetup && merchantMode && (
        <div className="glass-card-elevated rounded-2xl p-4 space-y-3 border border-primary/15 animate-scale-in">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-foreground text-sm flex items-center gap-2"><Lock size={15} className="text-primary" /> {hasPin ? t("shop.pin.change") : t("shop.pin.set")}</h3>
            <button onClick={() => setShowPinSetup(false)} className="text-muted-foreground"><X size={17} /></button>
          </div>
          <input type="text" placeholder={t("shop.pin.enter")} value={newPin}
            onChange={(e) => setNewPin(e.target.value)}
            className="w-full p-3 rounded-xl border border-input bg-card text-foreground text-lg font-bold text-center tracking-widest" />
          <button onClick={handleSetPin} disabled={!newPin.trim()}
            className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold disabled:opacity-40 btn-press">{t("btn.save")}</button>
        </div>
      )}

      {/* Quick Add */}
      {showQuickAdd && (
        <div className="glass-card-elevated rounded-2xl p-4 space-y-3 border border-primary/15 animate-scale-in">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-foreground text-sm">{t("shop.quick.add")}</h3>
            <button onClick={() => { setShowQuickAdd(false); setPhoto(undefined); }} className="text-muted-foreground"><X size={17} /></button>
          </div>
          <input type="number" inputMode="numeric" placeholder={t("shop.sell.price")} value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full p-3.5 rounded-xl border border-input bg-card text-foreground text-lg font-bold text-center" autoFocus />
          {merchantMode && (
            <input type="number" inputMode="numeric" placeholder={t("shop.cost.price")} value={costPrice}
              onChange={(e) => setCostPrice(e.target.value)}
              className="w-full p-3 rounded-xl border border-input bg-card text-foreground text-sm font-bold text-center" />
          )}
          <input type="text" placeholder={t("shop.note.placeholder")} value={note}
            onChange={(e) => setNote(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleQuickAdd()}
            className="w-full p-3 rounded-xl border border-input bg-card text-foreground text-sm" />
          <div>
            <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handlePhotoCapture} />
            {photo ? (
              <div className="relative">
                <img src={photo} alt="" className="w-full h-32 object-cover rounded-xl" />
                <button onClick={() => setPhoto(undefined)} className="absolute top-1 left-1 bg-danger text-danger-foreground rounded-full p-1"><X size={13} /></button>
              </div>
            ) : (
              <button onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 p-3 rounded-xl border-2 border-dashed border-input text-muted-foreground hover:border-primary hover:text-primary transition-colors text-sm btn-press">
                <Camera size={17} /> {t("camera.attach.short")}
              </button>
            )}
          </div>
          <button onClick={handleQuickAdd} disabled={!amount}
            className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold disabled:opacity-40 btn-press shadow-sm">{t("shop.register")}</button>
        </div>
      )}

      {/* Search & Filter */}
      <div className="space-y-2">
        <div className="relative">
          <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input type="text" placeholder={t("shop.search")} value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-input bg-card/80 text-foreground text-sm" />
        </div>
        <div className="flex gap-2">
          {(["all", "unpaid", "paid"] as const).map(f => (
            <button key={f} onClick={() => setFilterStatus(f)}
              className={`flex-1 py-2 rounded-xl font-semibold text-xs transition-all btn-press ${
                filterStatus === f ? "gradient-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground"
              }`}>
              {f === "all" ? t("reports.all") : f === "unpaid" ? t("reports.unpaid") : t("reports.paid")}
            </button>
          ))}
        </div>
      </div>

      {/* Purchase History */}
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-foreground flex items-center gap-2 text-sm">
          <ShoppingBag size={16} className="text-primary" /> {t("shop.history")}
        </h2>
        <span className="text-[11px] text-muted-foreground bg-muted px-2 py-1 rounded-full">{filtered.length} {t("reports.transactions")}</span>
      </div>

      <ScrollArea className="h-[calc(100vh-540px)] min-h-[200px]">
        <div className="space-y-2 pb-20">
          {filtered.map(p => {
            const synced = syncedIds.has(p.id);
            return (
              <div key={p.id} className={`glass-card rounded-xl p-3.5 border-r-[3px] transition-all ${
                p.isPaid ? "border-r-success/40 opacity-55" : (p.paidAmount || 0) > 0 ? "border-r-warning" : "border-r-danger"
              }`}>
                {editingId === p.id ? (
                  <div className="space-y-2">
                    <input type="number" value={editAmount} onChange={e => setEditAmount(e.target.value)}
                      className="w-full p-2 rounded-lg border border-input bg-card text-foreground text-sm font-bold" />
                    <input type="text" value={editNote} onChange={e => setEditNote(e.target.value)}
                      className="w-full p-2 rounded-lg border border-input bg-card text-foreground text-sm" />
                    {hasPin && (
                      <div>
                        <input type="password" placeholder={t("shop.pin.enter")} value={editPin}
                          onChange={e => { setEditPin(e.target.value); setEditPinError(false); }}
                          className={`w-full p-2 rounded-lg border bg-card text-foreground text-sm text-center ${editPinError ? "border-danger" : "border-input"}`} />
                        {editPinError && <p className="text-danger text-[11px] mt-1">{t("shop.pin.wrong")}</p>}
                      </div>
                    )}
                    <div className="flex gap-2">
                      <button onClick={saveEdit} className="flex-1 gradient-primary text-primary-foreground py-2 rounded-lg text-sm font-bold btn-press">{t("btn.save")}</button>
                      <button onClick={() => setEditingId(null)} className="px-3 py-2 rounded-lg bg-muted text-muted-foreground text-sm btn-press">{t("btn.cancel")}</button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="font-semibold text-foreground text-sm truncate">{p.note || t("reports.no.note")}</p>
                          <DebtStatusBadge purchase={p} />
                          {synced && (
                            <span className="text-[9px] bg-success/10 text-success px-1.5 py-0.5 rounded-full font-bold flex items-center gap-0.5 shrink-0">
                              <ShieldCheck size={8} /> {t("status.synced")}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <p className="text-[11px] text-muted-foreground">{formatDateTime(p.date)}</p>
                          <span className="text-[10px] bg-primary/8 text-primary px-1.5 py-0.5 rounded font-mono font-bold flex items-center gap-0.5">
                            <Hash size={8} />{p.verificationCode || "---"}
                          </span>
                        </div>
                        {merchantMode && p.costPrice && p.costPrice > 0 && (
                          <p className="text-[10px] mt-0.5 text-primary">
                            {t("shop.profit")} {formatNumber(p.amount - p.costPrice)} {t("currency")}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5">
                        {!p.isPaid && (
                          <>
                            {merchantMode && (
                              <button onClick={() => setShowPayment(p.id)} className="p-1.5 text-muted-foreground hover:text-success transition-colors icon-hover">
                                <CreditCard size={13} />
                              </button>
                            )}
                            <button onClick={() => startEdit(p)} className="p-1.5 text-muted-foreground hover:text-primary transition-colors icon-hover"><Pencil size={13} /></button>
                            <button onClick={() => handleDelete(p.id)} className="p-1.5 text-muted-foreground hover:text-danger transition-colors icon-hover"><Trash2 size={13} /></button>
                          </>
                        )}
                        <p className={`font-bold text-base ${p.isPaid ? "text-muted-foreground" : "text-danger"}`}>
                          {formatNumber(p.amount)}
                          <span className="text-[9px] font-normal text-muted-foreground mr-0.5">{t("currency")}</span>
                        </p>
                      </div>
                    </div>
                    {/* Partial payment info */}
                    {!p.isPaid && (p.paidAmount || 0) > 0 && (
                      <div className="mt-1.5 flex items-center gap-2 text-[10px]">
                        <span className="text-warning font-semibold">{t("shop.paid.partial")} {formatNumber(p.paidAmount || 0)}</span>
                        <span className="text-muted-foreground">| {t("shop.remaining")} {formatNumber(p.amount - (p.paidAmount || 0))}</span>
                      </div>
                    )}
                    {/* Payment modal */}
                    {showPayment === p.id && (
                      <div className="mt-3 p-3 rounded-xl bg-secondary/50 space-y-2 animate-scale-in">
                        <p className="text-xs font-bold text-foreground">{t("shop.payment.title")}</p>
                        <input type="number" inputMode="numeric" placeholder={t("shop.payment.amount")} value={payAmount}
                          onChange={e => setPayAmount(e.target.value)}
                          className="w-full p-2.5 rounded-lg border border-input bg-card text-foreground text-sm font-bold text-center" />
                        <div className="flex gap-1.5 flex-wrap">
                          {["Bankily", "السداد", "مصريفي", "كليك", t("shop.payment.cash")].map(m => (
                            <button key={m} onClick={() => setPayMethod(m)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold btn-press ${payMethod === m ? "gradient-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                              {m}
                            </button>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handlePartialPayment(p.id)} disabled={!payAmount}
                            className="flex-1 gradient-primary text-primary-foreground py-2 rounded-lg text-sm font-bold btn-press disabled:opacity-40">{t("btn.confirm")}</button>
                          <button onClick={() => setShowPayment(null)} className="px-3 py-2 rounded-lg bg-muted text-muted-foreground text-sm btn-press">{t("btn.cancel")}</button>
                        </div>
                      </div>
                    )}
                    {p.photo && (
                      <button onClick={() => setViewingPhoto(p.photo!)} className="mt-2">
                        <img src={p.photo} alt="" className="h-14 w-20 object-cover rounded-lg border border-border" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <div className="w-14 h-14 rounded-2xl bg-muted mx-auto mb-2 flex items-center justify-center">
            <ShoppingBag size={24} className="opacity-30" />
          </div>
          <p className="font-semibold text-foreground">{t("shop.no.purchases")}</p>
          <button onClick={() => setShowQuickAdd(true)} className="text-primary font-semibold mt-2 text-sm btn-press">{t("shop.first.purchase")}</button>
        </div>
      )}

      {/* Photo Lightbox */}
      {viewingPhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in"
          style={{ background: "hsl(180 40% 20% / 0.85)" }}
          onClick={() => setViewingPhoto(null)}>
          <div className="relative max-w-full max-h-full">
            <img src={viewingPhoto} alt="" className="max-w-full max-h-[80vh] rounded-xl" />
            <button onClick={() => setViewingPhoto(null)} className="absolute top-2 left-2 glass-dark text-primary-foreground rounded-full p-2">
              <X size={18} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ShopDetail;
