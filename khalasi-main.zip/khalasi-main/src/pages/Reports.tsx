import { useEffect, useState } from "react";
import * as db from "@/lib/db";
import { formatNumber, formatDate } from "@/lib/format";
import { Hash, FileText } from "lucide-react";
import { t } from "@/lib/i18n";

const Reports = () => {
  const [purchases, setPurchases] = useState<db.Purchase[]>([]);
  const [shops, setShops] = useState<db.Shop[]>([]);
  const [filter, setFilter] = useState<"all" | "unpaid" | "paid">("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const [p, s] = await Promise.all([db.getPurchases(), db.getShops()]);
      setPurchases(p.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setShops(s);
      setLoading(false);
    };
    load();
  }, []);

  const shopName = (id: string) => shops.find(s => s.id === id)?.name || t("reports.deleted.shop");

  const filtered = purchases.filter(p => {
    if (filter === "unpaid") return !p.isPaid;
    if (filter === "paid") return p.isPaid;
    return true;
  });

  const totalFiltered = filtered.reduce((sum, p) => sum + p.amount, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-slide-up">
      <div className="flex items-center gap-2">
        <FileText size={20} className="text-primary" />
        <h1 className="text-lg font-extrabold text-foreground">{t("reports.title")}</h1>
      </div>

      <div className="flex gap-2">
        {(["all", "unpaid", "paid"] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`flex-1 py-2.5 rounded-xl font-semibold text-sm transition-all btn-press ${
              filter === f ? "gradient-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground"
            }`}>
            {f === "all" ? t("reports.all") : f === "unpaid" ? t("reports.unpaid") : t("reports.paid")}
          </button>
        ))}
      </div>

      <div className="glass-card-elevated rounded-2xl p-4">
        <p className="text-sm text-muted-foreground">
          {t("reports.total")}: <span className="font-extrabold text-foreground">{formatNumber(totalFiltered)} {t("currency")}</span>
          {" • "}{filtered.length} {t("reports.transactions")}
        </p>
      </div>

      <div className="space-y-2">
        {filtered.map(p => (
          <div key={p.id} className={`glass-card rounded-xl p-3.5 border-r-[3px] ${
            p.isPaid ? "opacity-55 border-r-success/40" : "border-r-danger"
          }`}>
            <div className="flex justify-between items-start">
              <div>
                <p className="font-semibold text-foreground text-sm">{p.note || t("reports.no.note")}</p>
                <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                  <p className="text-[11px] text-muted-foreground">{shopName(p.shopId)} • {formatDate(p.date)}</p>
                  <span className="text-[10px] bg-primary/8 text-primary px-1.5 py-0.5 rounded font-mono font-bold flex items-center gap-0.5">
                    <Hash size={8} />{p.verificationCode || "---"}
                  </span>
                </div>
              </div>
              <div className="text-left">
                <p className={`font-bold ${p.isPaid ? "text-success" : "text-danger"}`}>{formatNumber(p.amount)}</p>
                <p className="text-[10px] text-muted-foreground">{p.isPaid ? t("reports.paid") : t("reports.due")}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="text-center py-10 text-muted-foreground font-semibold">{t("reports.no.data")}</p>
      )}
    </div>
  );
};

export default Reports;
