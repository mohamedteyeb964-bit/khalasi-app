import { useEffect, useState, useRef } from "react";
import * as db from "@/lib/db";
import { isMerchant } from "@/lib/roles";
import { ShoppingCart, Check, Camera, X, Hash, Store, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { t } from "@/lib/i18n";

const AddPurchase = () => {
  const [shops, setShops] = useState<db.Shop[]>([]);
  const [selectedShop, setSelectedShop] = useState("");
  const [amount, setAmount] = useState("");
  const [costPrice, setCostPrice] = useState("");
  const [note, setNote] = useState("");
  const [photo, setPhoto] = useState<string | undefined>();
  const [success, setSuccess] = useState(false);
  const [lastCode, setLastCode] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const merchantMode = isMerchant();

  useEffect(() => {
    db.getShops().then(all => {
      setShops(all);
      if (all.length === 1) setSelectedShop(all[0].id);
      setLoading(false);
    });
  }, []);

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setPhoto(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (!selectedShop || !amount || isNaN(Number(amount)) || Number(amount) <= 0) return;
    const cp = costPrice && !isNaN(Number(costPrice)) ? Number(costPrice) : undefined;
    const p = await db.addPurchase(selectedShop, Number(amount), note.trim(), photo, cp);
    setLastCode(p.verificationCode);
    setSuccess(true);
    setAmount(""); setCostPrice(""); setNote(""); setPhoto(undefined);
    setTimeout(() => setSuccess(false), 4000);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const EntityIcon = merchantMode ? Users : Store;

  if (shops.length === 0) {
    return (
      <div className="text-center py-16 animate-slide-up">
        <div className="w-16 h-16 rounded-2xl bg-muted mx-auto mb-3 flex items-center justify-center">
          <EntityIcon size={28} className="text-muted-foreground opacity-40" />
        </div>
        <p className="font-semibold text-foreground">{merchantMode ? t("add.no.entity.merchant") : t("add.no.entity.customer")}</p>
        <button onClick={() => navigate("/shops")} className="text-primary font-semibold mt-2 text-sm btn-press">
          {merchantMode ? t("add.go.customers") : t("add.go.stores")}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-slide-up">
      <h1 className="text-lg font-extrabold text-foreground">
        {merchantMode ? t("add.title.merchant") : t("add.title.customer")}
      </h1>

      {success && (
        <div className="bg-success/10 border border-success/20 text-success rounded-xl p-3 space-y-1 animate-scale-in">
          <div className="flex items-center gap-2 font-semibold text-sm">
            <Check size={18} /> {t("add.success")}
          </div>
          <div className="flex items-center gap-1.5 text-sm">
            <Hash size={11} />
            <span>{t("shop.verify.code")} <strong className="font-mono tracking-wider">{lastCode}</strong></span>
          </div>
        </div>
      )}

      <div className="glass-card-elevated rounded-2xl p-5 space-y-4">
        <div>
          <label className="block text-sm font-bold text-foreground mb-2">
            {merchantMode ? t("add.select.customer") : t("add.select.store")}
          </label>
          <div className="grid grid-cols-2 gap-2">
            {shops.map(shop => (
              <button key={shop.id} onClick={() => setSelectedShop(shop.id)}
                className={`p-3 rounded-xl border-2 font-semibold text-sm transition-all btn-press flex items-center gap-2 justify-center ${
                  selectedShop === shop.id ? "border-primary bg-primary/8 text-primary" : "border-border text-foreground hover:border-primary/30"
                }`}>
                <EntityIcon size={14} className={selectedShop === shop.id ? "text-primary" : "text-muted-foreground"} />
                {shop.name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-foreground mb-2">{t("add.sell.price")}</label>
          <input type="number" inputMode="numeric" placeholder="0" value={amount}
            onChange={e => setAmount(e.target.value)}
            className="w-full p-4 rounded-xl border border-input bg-card text-foreground text-xl font-extrabold text-center" />
        </div>

        {merchantMode && (
          <div>
            <label className="block text-sm font-bold text-foreground mb-2">{t("add.cost.price")}</label>
            <input type="number" inputMode="numeric" placeholder="0" value={costPrice}
              onChange={e => setCostPrice(e.target.value)}
              className="w-full p-3 rounded-xl border border-input bg-card text-foreground text-lg font-bold text-center" />
            {amount && costPrice && Number(costPrice) > 0 && (
              <div className="mt-2 flex items-center justify-center gap-2 text-sm rounded-lg p-2 bg-primary/10">
                <span className="text-muted-foreground">{t("add.profit.label")}</span>
                <span className="font-extrabold text-primary">
                  {(Number(amount) - Number(costPrice)).toLocaleString("en-US")} {t("currency")}
                </span>
              </div>
            )}
          </div>
        )}

        <div>
          <label className="block text-sm font-bold text-foreground mb-2">{t("add.note")}</label>
          <input type="text" placeholder={t("add.note.placeholder")} value={note}
            onChange={e => setNote(e.target.value)}
            className="w-full p-3 rounded-xl border border-input bg-card text-foreground text-sm" />
        </div>

        <div>
          <label className="block text-sm font-bold text-foreground mb-2">{t("add.photo")}</label>
          <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handlePhotoCapture} />
          {photo ? (
            <div className="relative">
              <img src={photo} alt="" className="w-full h-36 object-cover rounded-xl" />
              <button onClick={() => setPhoto(undefined)} className="absolute top-1 left-1 bg-danger text-danger-foreground rounded-full p-1"><X size={13} /></button>
            </div>
          ) : (
            <button onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 p-3 rounded-xl border-2 border-dashed border-input text-muted-foreground hover:border-primary hover:text-primary transition-colors text-sm btn-press">
              <Camera size={17} /> {t("camera.attach")}
            </button>
          )}
        </div>

        <button onClick={handleSubmit} disabled={!selectedShop || !amount}
          className="w-full gradient-primary text-primary-foreground py-4 rounded-xl font-bold text-lg disabled:opacity-40 transition-opacity btn-press shadow-lg">
          {t("add.register")}
        </button>
      </div>
    </div>
  );
};

export default AddPurchase;
