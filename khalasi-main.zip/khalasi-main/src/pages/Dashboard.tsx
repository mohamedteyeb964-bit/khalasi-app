import { useEffect, useState } from "react";
import * as db from "@/lib/db";
import { formatNumber } from "@/lib/format";
import { isMerchant, isCustomer } from "@/lib/roles";
import { Wallet, TrendingDown, Store, ChevronLeft, BarChart3, QrCode, TrendingUp, DollarSign, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { t } from "@/lib/i18n";

const Dashboard = () => {
  const [totalDebt, setTotalDebt] = useState(0);
  const [totalPaid, setTotalPaid] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);
  const [budget, setBudgetState] = useState({ monthlyLimit: 0, month: "" });
  const [monthlySpent, setMonthlySpent] = useState(0);
  const [shops, setShops] = useState<{ id: string; name: string; debt: number }[]>([]);
  const [dailyData, setDailyData] = useState<{ day: string; amount: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [budgetInput, setBudgetInput] = useState("");
  const [editingBudget, setEditingBudget] = useState(false);
  const navigate = useNavigate();

  const merchantMode = isMerchant();
  const customerMode = isCustomer();

  useEffect(() => {
    const load = async () => {
      const [debt, paid, profit, budgetData, spent, allShops, daily] = await Promise.all([
        db.getTotalDebt(), db.getTotalPaid(), db.getTotalProfit(),
        db.getBudget(), db.getMonthlySpent(), db.getShops(), db.getDailySpending(),
      ]);
      setTotalDebt(debt); setTotalPaid(paid); setTotalProfit(profit);
      setBudgetState(budgetData); setMonthlySpent(spent); setDailyData(daily);
      const shopsWithDebt = await Promise.all(
        allShops.map(async (s) => ({ id: s.id, name: s.name, debt: await db.getShopDebt(s.id) }))
      );
      setShops(shopsWithDebt);
      setLoading(false);
    };
    load();
  }, []);

  const remaining = budget.monthlyLimit - monthlySpent;
  const budgetPercent = budget.monthlyLimit > 0 ? Math.min((monthlySpent / budget.monthlyLimit) * 100, 100) : 0;
  const isOverBudget = remaining < 0;

  const handleSetBudget = async () => {
    if (!budgetInput || isNaN(Number(budgetInput))) return;
    await db.setBudget(Number(budgetInput));
    setBudgetState({ monthlyLimit: Number(budgetInput), month: budget.month });
    setEditingBudget(false);
    setBudgetInput("");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-slide-up">
      {/* Hero Debt Card */}
      <div className="gradient-primary rounded-2xl p-5 text-primary-foreground relative overflow-hidden shadow-lg">
        <div className="absolute top-0 left-0 w-36 h-36 rounded-full bg-white/5 -translate-x-12 -translate-y-12" />
        <div className="absolute bottom-0 right-0 w-24 h-24 rounded-full bg-white/5 translate-x-8 translate-y-8" />
        <div className="flex items-center gap-3.5 relative z-10">
          <div className="w-13 h-13 rounded-2xl glass-dark flex items-center justify-center">
            {merchantMode ? <Store size={22} /> : <TrendingDown size={22} />}
          </div>
          <div>
            <p className="text-xs opacity-70 font-semibold">{merchantMode ? t("dash.total.merchant") : t("dash.total.customer")}</p>
            <p className="text-3xl font-extrabold mt-0.5">
              {formatNumber(totalDebt)} <span className="text-sm font-normal opacity-70">{t("currency")}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Merchant Summary Cards */}
      {merchantMode && (
        <div className="grid grid-cols-2 gap-3">
          <div className="glass-card-elevated rounded-2xl p-4">
            <div className="w-9 h-9 rounded-xl bg-success/10 flex items-center justify-center mb-2">
              <DollarSign size={16} className="text-success" />
            </div>
            <p className="text-[11px] text-muted-foreground font-semibold">{t("dash.paid")}</p>
            <p className="text-xl font-extrabold text-success mt-0.5">{formatNumber(totalPaid)}</p>
            <p className="text-[10px] text-muted-foreground">{t("currency")}</p>
          </div>
          <div className="glass-card-elevated rounded-2xl p-4">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center mb-2">
              <TrendingUp size={16} className="text-primary" />
            </div>
            <p className="text-[11px] text-muted-foreground font-semibold">{t("dash.profit")}</p>
            <p className="text-xl font-extrabold text-primary mt-0.5">{formatNumber(totalProfit)}</p>
            <p className="text-[10px] text-muted-foreground">{t("currency")}</p>
          </div>
        </div>
      )}

      {/* Customer sync shortcut */}
      {customerMode && (
        <button onClick={() => navigate("/sync")}
          className="w-full glass-card-elevated rounded-2xl p-4 flex items-center gap-3 hover:border-primary/20 transition-all btn-press">
          <div className="w-11 h-11 rounded-2xl gradient-primary flex items-center justify-center shadow-sm">
            <QrCode size={19} className="text-primary-foreground" />
          </div>
          <div className="flex-1 text-right">
            <p className="font-bold text-foreground text-sm">{t("dash.sync.title")}</p>
            <p className="text-[11px] text-muted-foreground">{t("dash.sync.desc")}</p>
          </div>
          <ChevronLeft size={16} className="text-muted-foreground" />
        </button>
      )}

      {/* Budget Card */}
      <div className="glass-card-elevated rounded-2xl p-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-28 h-28 rounded-full bg-primary/5 translate-x-10 -translate-y-10" />
        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 rounded-2xl gradient-primary flex items-center justify-center shadow-sm">
            <Wallet className="text-primary-foreground" size={20} />
          </div>
          <div className="flex-1 relative z-10">
            <p className="text-xs font-bold text-foreground">{t("dash.budget.title")}</p>
            <p className="text-[10px] text-muted-foreground">{t("currency")}</p>
          </div>
        </div>

        {budget.monthlyLimit > 0 && !editingBudget ? (
          <div className="relative z-10 space-y-2">
            <div className="flex items-baseline gap-2">
              <p className={`text-2xl font-extrabold ${isOverBudget ? "text-danger" : "text-foreground"}`}>
                {formatNumber(Math.abs(remaining))}
              </p>
              <span className="text-xs text-muted-foreground">{isOverBudget ? t("dash.budget.over") : t("dash.budget.remaining")}</span>
            </div>
            <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
              <div className={`h-full rounded-full transition-all duration-700 ${isOverBudget ? "bg-danger" : ""}`}
                style={{
                  width: `${budgetPercent}%`,
                  ...(!isOverBudget ? { background: "linear-gradient(90deg, hsl(180 55% 28%), hsl(185 45% 22%))" } : {}),
                }} />
            </div>
            <div className="flex justify-between text-[11px] text-muted-foreground">
              <span>{t("dash.budget.spent")}: {formatNumber(monthlySpent)}</span>
              <span>{t("dash.budget.limit")}: {formatNumber(budget.monthlyLimit)}</span>
            </div>
            <button onClick={() => { setEditingBudget(true); setBudgetInput(budget.monthlyLimit.toString()); }}
              className="text-[11px] text-primary font-semibold btn-press">{t("btn.edit")} ←</button>
          </div>
        ) : (
          <div className="relative z-10 space-y-3">
            <input type="number" inputMode="numeric" placeholder={t("dash.budget.placeholder")}
              value={budgetInput} onChange={e => setBudgetInput(e.target.value)}
              className="w-full p-3.5 rounded-xl border border-border bg-card text-foreground text-xl font-extrabold text-center placeholder:text-muted-foreground/50 placeholder:text-sm placeholder:font-normal"
              autoFocus />
            <div className="flex gap-2">
              <button onClick={handleSetBudget} disabled={!budgetInput}
                className="flex-1 py-3 rounded-xl font-bold text-sm btn-press gradient-primary text-primary-foreground shadow-sm disabled:opacity-40">
                {t("dash.budget.save")}
              </button>
              {editingBudget && (
                <button onClick={() => setEditingBudget(false)}
                  className="px-4 py-3 rounded-xl bg-muted text-muted-foreground font-semibold text-sm btn-press">{t("btn.cancel")}</button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Daily Chart */}
      {dailyData.some(d => d.amount > 0) && (
        <div className="glass-card-elevated rounded-2xl p-4">
          <h2 className="font-bold text-foreground mb-3 flex items-center gap-2 text-sm">
            <BarChart3 size={17} className="text-primary" /> {t("dash.chart")}
          </h2>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyData}>
                <defs>
                  <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(180, 55%, 28%)" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="hsl(180, 55%, 28%)" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" tick={{ fontSize: 10 }} interval="preserveStartEnd" />
                <YAxis hide />
                <Tooltip
                  formatter={(value: number) => [`${formatNumber(value)} ${t("currency")}`, t("dash.chart.expense")]}
                  labelFormatter={(label) => `${t("dash.chart.day")} ${label}`}
                  contentStyle={{ borderRadius: 12, fontSize: 12, direction: "rtl", background: "hsl(178 28% 96%)", border: "1px solid hsl(178 20% 82%)", boxShadow: "0 4px 20px hsl(180 30% 50% / 0.08)" }}
                />
                <Area type="monotone" dataKey="amount" stroke="hsl(180, 55%, 28%)" strokeWidth={2} fill="url(#colorAmount)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Shop/Customer Overview */}
      {shops.length > 0 && (
        <div className="glass-card-elevated rounded-2xl p-4">
          <h2 className="font-bold text-foreground mb-3 flex items-center gap-2 text-sm">
            {merchantMode ? <Users size={17} className="text-primary" /> : <Store size={17} className="text-primary" />}
            {merchantMode ? t("dash.summary.merchant") : t("dash.summary.customer")}
          </h2>
          <div className="space-y-2">
            {shops.map((shop) => (
              <button key={shop.id} onClick={() => navigate(`/shops/${shop.id}`)}
                className="w-full flex items-center justify-between p-3.5 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors group btn-press">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-primary/8 flex items-center justify-center">
                    {merchantMode ? <Users size={16} className="text-primary" /> : <Store size={16} className="text-primary" />}
                  </div>
                  <span className="font-semibold text-foreground text-sm">{shop.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`font-bold text-sm ${shop.debt > 0 ? "text-danger" : "text-success"}`}>
                    {shop.debt > 0 ? `${formatNumber(shop.debt)} ${t("currency")}` : t("dash.no.debt")}
                  </span>
                  <ChevronLeft size={15} className="text-muted-foreground group-hover:text-foreground transition-colors" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {shops.length === 0 && (
        <div className="text-center py-10 text-muted-foreground">
          <div className="w-16 h-16 rounded-2xl bg-muted mx-auto mb-3 flex items-center justify-center">
            {merchantMode ? <Users size={28} className="opacity-40" /> : <Store size={28} className="opacity-40" />}
          </div>
          <p className="font-semibold text-foreground">{merchantMode ? t("dash.no.entities.merchant") : t("dash.no.entities.customer")}</p>
          <button onClick={() => navigate("/add")} className="text-primary font-semibold mt-2 text-sm btn-press">
            {merchantMode ? t("dash.add.first.merchant") : t("dash.add.first.customer")}
          </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
