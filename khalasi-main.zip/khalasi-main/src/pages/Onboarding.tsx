import { useState } from "react";
import { setUserRole, UserRole } from "@/lib/roles";
import { Store, ShoppingBag, Shield } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { t } from "@/lib/i18n";
import logoImg from "@/assets/khalasi-logo.png";

const Onboarding = () => {
  const [selected, setSelected] = useState<UserRole | null>(null);
  const navigate = useNavigate();

  const handleContinue = () => {
    if (!selected) return;
    setUserRole(selected);
    navigate("/");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-10 animate-slide-up gradient-primary">
      <div className="w-24 h-24 mb-4">
        <img src={logoImg} alt="خلاصي" className="w-full h-full object-contain drop-shadow-lg" />
      </div>

      <h1 className="text-2xl font-extrabold text-white mb-1">{t("app.name")}</h1>
      <p className="text-xs text-white/50 tracking-wide font-semibold mb-1">KHALASI</p>
      <p className="text-white/60 text-center text-sm mb-8 max-w-xs leading-relaxed">{t("onboarding.title")}</p>

      <div className="w-full max-w-sm space-y-3">
        <button onClick={() => setSelected("merchant")}
          className={`w-full rounded-2xl p-5 text-right transition-all btn-press ${
            selected === "merchant"
              ? "bg-white/20 border-2 border-white/50 scale-[1.01]"
              : "bg-white/8 border border-white/15 hover:bg-white/12"
          }`}
          style={{ backdropFilter: "blur(12px)" }}>
          <div className="flex items-start gap-4">
            <div className={`w-13 h-13 rounded-2xl flex items-center justify-center shrink-0 transition-colors ${
              selected === "merchant" ? "bg-white/20" : "bg-white/10"
            }`}>
              <Store size={24} className="text-white icon-hover" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-white text-base">{t("onboarding.merchant")}</p>
              <p className="text-sm text-white/60 mt-1 leading-relaxed">{t("onboarding.merchant.desc")}</p>
              <div className="flex items-center gap-1.5 mt-2">
                <Shield size={11} className="text-white/70" />
                <span className="text-[11px] text-white/70 font-semibold">PIN</span>
              </div>
            </div>
          </div>
        </button>

        <button onClick={() => setSelected("customer")}
          className={`w-full rounded-2xl p-5 text-right transition-all btn-press ${
            selected === "customer"
              ? "bg-white/20 border-2 border-white/50 scale-[1.01]"
              : "bg-white/8 border border-white/15 hover:bg-white/12"
          }`}
          style={{ backdropFilter: "blur(12px)" }}>
          <div className="flex items-start gap-4">
            <div className={`w-13 h-13 rounded-2xl flex items-center justify-center shrink-0 transition-colors ${
              selected === "customer" ? "bg-white/20" : "bg-white/10"
            }`}>
              <ShoppingBag size={24} className="text-white icon-hover" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-white text-base">{t("onboarding.customer")}</p>
              <p className="text-sm text-white/60 mt-1 leading-relaxed">{t("onboarding.customer.desc")}</p>
              <div className="flex items-center gap-1.5 mt-2">
                <ShoppingBag size={11} className="text-white/70" />
                <span className="text-[11px] text-white/70 font-semibold">QR Sync</span>
              </div>
            </div>
          </div>
        </button>
      </div>

      <button onClick={handleContinue} disabled={!selected}
        className="w-full max-w-sm bg-white/15 border border-white/25 text-white py-4 rounded-2xl font-bold text-lg mt-8 disabled:opacity-30 transition-all shadow-lg btn-press"
        style={selected ? { background: "hsl(0 0% 100% / 0.2)", borderColor: "hsl(0 0% 100% / 0.4)" } : undefined}>
        {t("onboarding.continue")}
      </button>
    </div>
  );
};

export default Onboarding;
