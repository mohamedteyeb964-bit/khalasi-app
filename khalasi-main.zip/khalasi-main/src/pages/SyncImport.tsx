import { useState, useRef, useEffect, useCallback } from "react";
import { parseSyncCode, SyncData, isMerchant } from "@/lib/roles";
import { verifySignedQRPayload, type SignedQRData } from "@/lib/hmac";
import * as db from "@/lib/db";
import { formatNumber, formatDate, formatDateTime } from "@/lib/format";
import { ArrowRight, CheckCircle, QrCode, Download, ShieldCheck, ImageIcon, Shield, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { t } from "@/lib/i18n";

const SyncImport = () => {
  const [code, setCode] = useState("");
  const [preview, setPreview] = useState<SyncData | null>(null);
  const [qrPreview, setQrPreview] = useState<SignedQRData | null>(null);
  const [error, setError] = useState("");
  const [imported, setImported] = useState(false);
  const [importCount, setImportCount] = useState(0);
  const [cameraActive, setCameraActive] = useState(false);

  const galleryRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const scanCanvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number>(0);
  const navigate = useNavigate();
  const merchantMode = isMerchant();

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    cancelAnimationFrame(animFrameRef.current);
    setCameraActive(false);
  }, []);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const processQRData = useCallback(async (rawData: string) => {
    stopCamera();
    setCode(rawData);
    try {
      const parsed = JSON.parse(rawData);
      if (parsed.v === 2) {
        const result = await verifySignedQRPayload(rawData);
        if (result.valid && result.data) { setQrPreview(result.data); setPreview(null); setError(""); }
        else { setError(t("sync.invalid.sig")); }
        return;
      }
    } catch {}

    const syncData = parseSyncCode(rawData);
    if (syncData) { setPreview(syncData); setQrPreview(null); setError(""); }
    else { setError(t("sync.invalid.code")); setPreview(null); setQrPreview(null); }
  }, [stopCamera]);

  const scanFrame = useCallback(() => {
    if (!videoRef.current || !scanCanvasRef.current || videoRef.current.readyState !== videoRef.current.HAVE_ENOUGH_DATA) {
      animFrameRef.current = requestAnimationFrame(scanFrame);
      return;
    }
    const video = videoRef.current;
    const canvas = scanCanvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    import("jsqr").then(({ default: jsQR }) => {
      const qr = jsQR(imageData.data, canvas.width, canvas.height);
      if (qr && qr.data) {
        processQRData(qr.data);
      } else {
        animFrameRef.current = requestAnimationFrame(scanFrame);
      }
    });
  }, [processQRData]);

  const startCamera = async () => {
    setError(""); // تصفير الأخطاء السابقة عند إعادة المحاولة
    try {
      // Request real camera permission
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraActive(true);
      animFrameRef.current = requestAnimationFrame(scanFrame);
    } catch (err: any) {
      if (err?.name === "NotAllowedError" || err?.name === "PermissionDeniedError") {
        // رسالة مخصصة مع توجيه صريح
        setError(t("camera.denied") + " - يرجى السماح للكاميرا من إعدادات المتصفح (Site Settings) ثم المحاولة مجدداً.");
      } else {
        setError(t("camera.no.access"));
      }
    }
  };

  const handleParse = () => {
    try {
      const parsed = JSON.parse(code);
      if (parsed.v === 2) {
        verifySignedQRPayload(code).then(({ valid, data }) => {
          if (valid && data) {
            setQrPreview(data); setPreview(null); setError("");
          } else {
            setError(t("sync.invalid.sig"));
          }
        });
        return;
      }
    } catch {}
    const data = parseSyncCode(code);
    if (data) { setPreview(data); setQrPreview(null); setError(""); }
    else { setError(t("sync.invalid.code")); setPreview(null); setQrPreview(null); }
  };

  const handleImportLegacy = async () => {
    if (!preview) return;
    const shops = await db.getShops();
    let existingShop = shops.find(s => s.name === preview.shopName);
    let shopId: string;
    if (existingShop) { shopId = existingShop.id; } else { shopId = (await db.addShop(preview.shopName)).id; }
    const existingPurchases = await db.getShopPurchases(shopId);
    const existingCodes = new Set(existingPurchases.map(p => p.verificationCode));
    const syncIds: string[] = [];
    let count = 0;
    for (const p of preview.purchases) {
      if (!existingCodes.has(p.verificationCode)) {
        const added = await db.addPurchase(shopId, p.amount, p.note || "", p.photo);
        syncIds.push(added.id);
        count++;
      }
      syncIds.push(p.id);
    }
    await db.markPurchasesAsSynced(syncIds);
    setImportCount(count);
    setImported(true);
  };

  const handleImportQR = async () => {
    if (!qrPreview) return;
    const shops = await db.getShops();
    let existingShop = shops.find(s => s.name === qrPreview.sn);
    let shopId: string;
    if (existingShop) { shopId = existingShop.id; } else { shopId = (await db.addShop(qrPreview.sn)).id; }
    const existingPurchases = await db.getShopPurchases(shopId);
    const existingCodes = new Set(existingPurchases.map(p => p.verificationCode));
    const syncIds: string[] = [];
    let count = 0;
    for (const tx of qrPreview.txs) {
      if (!existingCodes.has(tx.code)) {
        const added = await db.addPurchase(shopId, tx.amt, tx.note || "");
        syncIds.push(added.id);
        count++;
      }
      syncIds.push(tx.id);
    }
    await db.markPurchasesAsSynced(syncIds);
    setImportCount(count);
    setImported(true);
  };

  const handleGalleryImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement("canvas");
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("no ctx");
      ctx.drawImage(bitmap, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const { default: jsQR } = await import("jsqr");
      const qr = jsQR(imageData.data, canvas.width, canvas.height);
      if (qr && qr.data) {
        setCode(qr.data);
        try {
          const parsed = JSON.parse(qr.data);
          if (parsed.v === 2) {
            const { valid, data } = await verifySignedQRPayload(qr.data);
            if (valid && data) { setQrPreview(data); setPreview(null); setError(""); }
            else { setError(t("sync.invalid.sig")); }
            return;
          }
        } catch {}
        const syncData = parseSyncCode(qr.data);
        if (syncData) { setPreview(syncData); setError(""); }
        else { setError(t("sync.invalid.code")); }
      } else {
        setError(t("sync.no.qr.found"));
      }
    } catch {
      setError(t("sync.image.error"));
    }
  };

  if (imported) {
    return (
      <div className="text-center py-16 animate-slide-up space-y-4">
        <div className="w-20 h-20 rounded-2xl bg-success/10 mx-auto flex items-center justify-center">
          <ShieldCheck size={34} className="text-success" />
        </div>
        <h1 className="text-xl font-extrabold text-foreground">{t("sync.success")}</h1>
        <p className="text-muted-foreground text-sm">{t("sync.imported").replace("{count}", importCount.toString())}</p>
        <button onClick={() => navigate("/shops")} className="gradient-primary text-primary-foreground px-6 py-3 rounded-xl font-bold btn-press shadow-sm">
          {merchantMode ? t("nav.customers") : t("nav.stores")}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-slide-up">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-primary font-semibold text-sm btn-press">
        <ArrowRight size={15} /> {t("btn.back")}
      </button>

      <div className="text-center">
        <div className="w-16 h-16 rounded-2xl gradient-primary mx-auto flex items-center justify-center mb-3 shadow-sm">
          <QrCode size={26} className="text-primary-foreground" />
        </div>
        <h1 className="text-xl font-extrabold text-foreground">
          {merchantMode ? t("sync.title.merchant") : t("sync.title.customer")}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          {merchantMode ? t("sync.merchant.desc") : t("sync.customer.desc")}
        </p>
      </div>

      {/* Live Camera QR Scanner */}
      <div className="glass-card-elevated rounded-2xl p-5 space-y-4">
        <div className="relative w-full aspect-square rounded-xl overflow-hidden flex items-center justify-center"
          style={{ background: "linear-gradient(135deg, hsl(180 40% 20%), hsl(185 35% 15%))" }}>
          
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
          
          {/* Scanner frame overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-56 h-56 border-2 border-white/60 rounded-2xl relative">
              <div className="absolute -top-0.5 -left-0.5 w-6 h-6 border-t-[3px] border-l-[3px] border-primary rounded-tl-lg" />
              <div className="absolute -top-0.5 -right-0.5 w-6 h-6 border-t-[3px] border-r-[3px] border-primary rounded-tr-lg" />
              <div className="absolute -bottom-0.5 -left-0.5 w-6 h-6 border-b-[3px] border-l-[3px] border-primary rounded-bl-lg" />
              <div className="absolute -bottom-0.5 -right-0.5 w-6 h-6 border-b-[3px] border-r-[3px] border-primary rounded-br-lg" />
            </div>
          </div>
          
          <p className="absolute bottom-4 left-0 right-0 text-center text-white text-sm font-bold drop-shadow-lg">
            {t("camera.frame.hint")}
          </p>

          {!cameraActive && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3"
              style={{ background: "linear-gradient(135deg, hsl(180 40% 22% / 0.9), hsl(185 35% 18% / 0.9))" }}>
              <QrCode size={40} className="text-white/50" />
              <button onClick={startCamera} className="gradient-primary text-primary-foreground px-6 py-2 rounded-xl font-bold btn-press text-sm">
                {t("camera.start")}
              </button>
            </div>
          )}
        </div>

        <canvas ref={scanCanvasRef} className="hidden" />

        {/* عرض الخطأ مع زر إعادة المحاولة */}
        {error && (
          <div className="flex flex-col gap-3 bg-danger/10 p-4 rounded-xl border border-danger/20">
            <div className="flex items-start gap-2 text-danger text-[13px] font-semibold leading-snug">
              <Shield size={16} className="shrink-0 mt-0.5" /> 
              <span>{error}</span>
            </div>
            {!cameraActive && error.includes("إعدادات المتصفح") && (
              <button onClick={startCamera} className="w-full bg-danger text-white px-4 py-2.5 rounded-xl font-bold text-sm shadow-sm btn-press flex items-center justify-center gap-2">
                <ArrowRight size={16} className="rotate-180" /> إعادة تشغيل الكاميرا (Retry)
              </button>
            )}
          </div>
        )}

        <div className="flex gap-2">
          <input ref={galleryRef} type="file" accept="image/*" className="hidden" onChange={handleGalleryImport} />
          <button onClick={() => galleryRef.current?.click()}
            className="w-full flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl border border-primary/20 text-primary font-bold text-sm btn-press hover:bg-primary/5 transition-colors">
            <ImageIcon size={16} /> {t("sync.gallery")}
          </button>
        </div>
      </div>

      {/* QR v2 Preview */}
      {qrPreview && (
        <div className="glass-card-elevated rounded-2xl p-5 space-y-4 border border-success/15 animate-scale-in">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-success" />
            <h3 className="font-bold text-foreground text-sm">{t("sync.signed.data")}</h3>
          </div>
          <div className="bg-success/5 rounded-xl p-4 border border-success/10">
            <p className="font-bold text-foreground">{qrPreview.sn}</p>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-[11px] text-muted-foreground">{qrPreview.txs.length} {t("reports.transactions")} • HMAC-SHA256</p>
              <div className="flex items-center gap-1 text-[10px] text-primary">
                <Clock size={9} /> {t("sync.last.update")}: {formatDateTime(qrPreview.ts)}
              </div>
            </div>
          </div>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {qrPreview.txs.map((tx, i) => (
              <div key={i} className="flex justify-between items-center p-2.5 rounded-lg bg-secondary/50">
                <div>
                  <p className="text-sm font-semibold text-foreground">{tx.note || t("reports.no.note")}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(tx.date)} • [{tx.code}]</p>
                </div>
                <p className="font-bold text-danger">{formatNumber(tx.amt)} <span className="text-[10px] text-muted-foreground">{t("currency")}</span></p>
              </div>
            ))}
          </div>
          <div className="border-t border-border pt-3 flex justify-between items-center">
            <span className="font-bold text-foreground">{t("reports.total")}</span>
            <span className="text-xl font-extrabold text-danger">{formatNumber(qrPreview.txs.reduce((s, t) => s + t.amt, 0))} {t("currency")}</span>
          </div>
          <button onClick={handleImportQR}
            className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold flex items-center justify-center gap-2 btn-press shadow-sm">
            <ShieldCheck size={17} /> {t("sync.confirm.import")}
          </button>
        </div>
      )}

      {/* Legacy Preview */}
      {preview && (
        <div className="glass-card-elevated rounded-2xl p-5 space-y-4 border border-primary/15 animate-scale-in">
          <h3 className="font-bold text-foreground flex items-center gap-2 text-sm">
            <Download size={16} className="text-primary" /> {t("sync.preview.data")}
          </h3>
          <div className="bg-primary/5 rounded-xl p-4">
            <p className="font-bold text-foreground">{preview.shopName}</p>
            <p className="text-[11px] text-muted-foreground mt-1">
              {preview.purchases.length} {t("reports.transactions")} • {formatDate(preview.exportedAt)}
            </p>
          </div>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {preview.purchases.map((p, i) => (
              <div key={i} className="flex justify-between items-center p-2.5 rounded-lg bg-secondary/50">
                <div>
                  <p className="text-sm font-semibold text-foreground">{p.note || t("reports.no.note")}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(p.date)} • [{p.verificationCode}]</p>
                </div>
                <p className="font-bold text-danger">{formatNumber(p.amount)} <span className="text-[10px] text-muted-foreground">{t("currency")}</span></p>
              </div>
            ))}
          </div>
          <button onClick={handleImportLegacy}
            className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold flex items-center justify-center gap-2 btn-press shadow-sm">
            <CheckCircle size={17} /> {t("sync.confirm.legacy")}
          </button>
        </div>
      )}
    </div>
  );
};

export default SyncImport;
