import { useState, useRef } from "react";
import { verifySignedQRPayload, type SignedQRData } from "@/lib/hmac";
import { parseSyncCode, SyncData } from "@/lib/roles";
import * as db from "@/lib/db";
import { formatNumber, formatDate, formatDateTime } from "@/lib/format";
import { ImageDown, ShieldCheck, CheckCircle, Shield, ArrowRight, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { t } from "@/lib/i18n";

const GalleryImport = () => {
  const [preview, setPreview] = useState<SyncData | null>(null);
  const [qrPreview, setQrPreview] = useState<SignedQRData | null>(null);
  const [error, setError] = useState("");
  const [imported, setImported] = useState(false);
  const [importCount, setImportCount] = useState(0);
  const galleryRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const handleGalleryImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement("canvas");
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("no ctx");
      ctx.drawImage(bitmap, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const { default: jsQR } = await import("jsqr");
      const qr = jsQR(imageData.data, canvas.width, canvas.height);
      if (qr && qr.data) {
        try {
          const parsed = JSON.parse(qr.data);
          if (parsed.v === 2) {
            const { valid, data } = await verifySignedQRPayload(qr.data);
            if (valid && data) {
              setQrPreview(data); setPreview(null); setError("");
            } else {
              setError(t("sync.invalid.sig"));
            }
            return;
          }
        } catch {}
        const syncData = parseSyncCode(qr.data);
        if (syncData) { setPreview(syncData); setError(""); }
        else { setError(t("sync.invalid.code")); }
      } else {
        setError(t("sync.no.qr.found"));
      }
    } catch {
      setError(t("sync.image.error"));
    }
  };

  const handleImportQR = async () => {
    if (!qrPreview) return;
    const shops = await db.getShops();
    let existingShop = shops.find(s => s.name === qrPreview.sn);
    let shopId: string;
    if (existingShop) { shopId = existingShop.id; } else { shopId = (await db.addShop(qrPreview.sn)).id; }

    const existingPurchases = await db.getShopPurchases(shopId);
    const existingCodes = new Set(existingPurchases.map(p => p.verificationCode));
    const syncIds: string[] = [];
    let count = 0;

    for (const tx of qrPreview.txs) {
      if (!existingCodes.has(tx.code)) {
        const added = await db.addPurchase(shopId, tx.amt, tx.note || "");
        syncIds.push(added.id);
        count++;
      }
      syncIds.push(tx.id);
    }

    await db.markPurchasesAsSynced(syncIds);
    setImportCount(count);
    setImported(true);
  };

  const handleImportLegacy = async () => {
    if (!preview) return;
    const shops = await db.getShops();
    let existingShop = shops.find(s => s.name === preview.shopName);
    let shopId: string;
    if (existingShop) { shopId = existingShop.id; } else { shopId = (await db.addShop(preview.shopName)).id; }

    const existingPurchases = await db.getShopPurchases(shopId);
    const existingCodes = new Set(existingPurchases.map(p => p.verificationCode));
    const syncIds: string[] = [];
    let count = 0;

    for (const p of preview.purchases) {
      if (!existingCodes.has(p.verificationCode)) {
        const added = await db.addPurchase(shopId, p.amount, p.note || "", p.photo);
        syncIds.push(added.id);
        count++;
      }
      syncIds.push(p.id);
    }

    await db.markPurchasesAsSynced(syncIds);
    setImportCount(count);
    setImported(true);
  };

  if (imported) {
    return (
      <div className="text-center py-16 animate-slide-up space-y-4">
        <div className="w-20 h-20 rounded-2xl bg-success/10 mx-auto flex items-center justify-center">
          <ShieldCheck size={34} className="text-success" />
        </div>
        <h1 className="text-xl font-extrabold text-foreground">{t("sync.success")}</h1>
        <p className="text-muted-foreground text-sm">{t("sync.imported").replace("{count}", importCount.toString())}</p>
        <button onClick={() => navigate("/shops")} className="gradient-primary text-primary-foreground px-6 py-3 rounded-xl font-bold btn-press shadow-sm">
          {t("nav.stores")}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-slide-up">
      <div className="text-center">
        <div className="w-16 h-16 rounded-2xl gradient-primary mx-auto flex items-center justify-center mb-3 shadow-sm">
          <ImageDown size={26} className="text-primary-foreground" />
        </div>
        <h1 className="text-xl font-extrabold text-foreground">{t("gallery.title")}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t("gallery.desc")}</p>
      </div>

      <div className="glass-card-elevated rounded-2xl p-5 space-y-4">
        <input ref={galleryRef} type="file" accept="image/*" className="hidden" onChange={handleGalleryImport} />
        <button onClick={() => galleryRef.current?.click()}
          className="w-full flex flex-col items-center justify-center gap-3 p-8 rounded-xl border-2 border-dashed border-primary/30 text-primary hover:border-primary hover:bg-primary/5 transition-all btn-press">
          <ImageDown size={40} />
          <span className="font-bold text-lg">{t("gallery.select")}</span>
          <span className="text-sm text-muted-foreground">{t("gallery.select.desc")}</span>
        </button>

        {error && (
          <div className="flex items-center gap-2 text-danger text-[11px] font-semibold bg-danger/5 p-2 rounded-lg">
            <Shield size={12} /> {error}
          </div>
        )}
      </div>

      {/* QR v2 Preview */}
      {qrPreview && (
        <div className="glass-card-elevated rounded-2xl p-5 space-y-4 border border-success/15 animate-scale-in">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-success" />
            <h3 className="font-bold text-foreground text-sm">{t("sync.signed.data")}</h3>
          </div>
          <div className="bg-success/5 rounded-xl p-4 border border-success/10">
            <p className="font-bold text-foreground">{qrPreview.sn}</p>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-[11px] text-muted-foreground">{qrPreview.txs.length} {t("reports.transactions")}</p>
              <div className="flex items-center gap-1 text-[10px] text-primary">
                <Clock size={9} /> {t("sync.last.update")}: {formatDateTime(qrPreview.ts)}
              </div>
            </div>
          </div>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {qrPreview.txs.map((tx, i) => (
              <div key={i} className="flex justify-between items-center p-2.5 rounded-lg bg-secondary/50">
                <div>
                  <p className="text-sm font-semibold text-foreground">{tx.note || t("reports.no.note")}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(tx.date)} • [{tx.code}]</p>
                </div>
                <p className="font-bold text-danger">{formatNumber(tx.amt)} <span className="text-[10px] text-muted-foreground">{t("currency")}</span></p>
              </div>
            ))}
          </div>
          <button onClick={handleImportQR}
            className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold flex items-center justify-center gap-2 btn-press shadow-sm">
            <ShieldCheck size={17} /> {t("sync.confirm.import")}
          </button>
        </div>
      )}

      {/* Legacy Preview */}
      {preview && (
        <div className="glass-card-elevated rounded-2xl p-5 space-y-4 border border-primary/15 animate-scale-in">
          <div className="bg-primary/5 rounded-xl p-4">
            <p className="font-bold text-foreground">{preview.shopName}</p>
            <p className="text-[11px] text-muted-foreground mt-1">{preview.purchases.length} {t("reports.transactions")}</p>
          </div>
          <button onClick={handleImportLegacy}
            className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold flex items-center justify-center gap-2 btn-press shadow-sm">
            <CheckCircle size={17} /> {t("sync.confirm.legacy")}
          </button>
        </div>
      )}
    </div>
  );
};

export default GalleryImport;
