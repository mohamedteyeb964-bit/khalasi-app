import { useEffect, useState } from "react";
import * as db from "@/lib/db";
import { formatCurrency } from "@/lib/format";
import { isPremium } from "@/lib/device";
import { isMerchant } from "@/lib/roles";
import { Plus, Trash2, ChevronLeft, Store, Lock, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import PaywallScreen from "@/components/PaywallScreen";
import { t } from "@/lib/i18n";

const Shops = () => {
  const [shops, setShops] = useState<(db.Shop & { debt: number })[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState("");
  const [showPaywall, setShowPaywall] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const merchantMode = isMerchant();

  const loadShops = async () => {
    const all = await db.getShops();
    const withDebt = await Promise.all(
      all.map(async (s) => ({ ...s, debt: await db.getShopDebt(s.id) }))
    );
    setShops(withDebt);
    setLoading(false);
  };

  useEffect(() => { loadShops(); }, []);

  const handleAdd = async () => {
    if (!newName.trim()) return;
    const canAdd = await db.canAddMore();
    if (!canAdd) { setShowPaywall(true); return; }
    await db.addShop(newName.trim());
    setNewName(""); setShowAdd(false); loadShops();
  };

  const handleDelete = async (id: string, name: string) => {
    const msg = t("entity.delete.confirm").replace("{name}", name);
    if (confirm(msg)) {
      await db.deleteShop(id);
      loadShops();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const EntityIcon = merchantMode ? Users : Store;

  return (
    <div className="space-y-4 animate-slide-up">
      {showPaywall && (
        <PaywallScreen onActivated={() => setShowPaywall(false)} onClose={() => setShowPaywall(false)} />
      )}

      <div className="flex items-center justify-between">
        <h1 className="text-lg font-extrabold text-foreground flex items-center gap-2">
          <EntityIcon size={20} className="text-primary" />
          {merchantMode ? t("entity.customers") : t("entity.stores")}
        </h1>
        <button onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-1.5 gradient-primary text-primary-foreground px-4 py-2.5 rounded-xl font-semibold text-sm shadow-sm btn-press">
          <Plus size={17} /> {t("btn.add")}
        </button>
      </div>

      {!isPremium() && shops.length >= 4 && (
        <div className="glass-card rounded-xl p-3 border border-warning/20 flex items-center gap-2">
          <Lock size={15} className="text-warning shrink-0" />
          <p className="text-[11px] text-muted-foreground">
            {t("entity.limit.near")}{" "}
            <button onClick={() => setShowPaywall(true)} className="text-primary font-bold">{t("entity.limit.upgrade")}</button>
          </p>
        </div>
      )}

      {showAdd && (
        <div className="glass-card-elevated rounded-2xl p-4 space-y-3 border border-primary/15 animate-scale-in">
          <input type="text" placeholder={merchantMode ? t("entity.name.placeholder.customer") : t("entity.name.placeholder.store")}
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAdd()}
            className="w-full p-3.5 rounded-xl border border-input bg-card text-foreground text-base" autoFocus />
          <button onClick={handleAdd} className="w-full gradient-primary text-primary-foreground py-3 rounded-xl font-bold text-base btn-press shadow-sm">{t("btn.save")}</button>
        </div>
      )}

      <div className="space-y-2.5">
        {shops.map((shop) => (
          <div key={shop.id}
            className="glass-card-elevated rounded-2xl p-4 flex items-center justify-between group hover:border-primary/15 transition-all">
            <button onClick={() => navigate(`/shops/${shop.id}`)} className="flex items-center gap-3 flex-1 text-right">
              <div className="w-11 h-11 rounded-2xl bg-primary/8 flex items-center justify-center shrink-0">
                <EntityIcon size={18} className="text-primary icon-hover" />
              </div>
              <div>
                <p className="font-bold text-foreground text-sm">{shop.name}</p>
                <p className={`text-xs font-semibold ${shop.debt > 0 ? "text-danger" : "text-success"}`}>
                  {shop.debt > 0 ? `${t("entity.debt.label")} ${formatCurrency(shop.debt)}` : t("dash.no.debt")}
                </p>
              </div>
            </button>
            <div className="flex items-center gap-1.5">
              <button onClick={() => handleDelete(shop.id, shop.name)} className="p-2 text-muted-foreground hover:text-danger transition-colors icon-hover">
                <Trash2 size={16} />
              </button>
              <button onClick={() => navigate(`/shops/${shop.id}`)} className="p-2 text-muted-foreground group-hover:text-primary transition-colors">
                <ChevronLeft size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {shops.length === 0 && !showAdd && (
        <div className="text-center py-14 text-muted-foreground">
          <div className="w-16 h-16 rounded-2xl bg-muted mx-auto mb-3 flex items-center justify-center">
            <EntityIcon size={28} className="opacity-30" />
          </div>
          <p className="font-semibold text-foreground">
            {merchantMode ? t("entity.none.customer") : t("entity.none.store")}
          </p>
          <p className="text-sm mt-1">{t("entity.add.start")}</p>
        </div>
      )}
    </div>
  );
};

export default Shops;
