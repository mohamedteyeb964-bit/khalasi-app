import { useState, useEffect, useCallback } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { getUserRole } from "@/lib/roles";
import { isPinSet, isSessionUnlocked } from "@/lib/pin";
import { getLocale, isRTL } from "@/lib/i18n";
import PinLock from "@/components/PinLock";
import SplashScreen from "@/components/SplashScreen";
import LanguageSelector from "@/components/LanguageSelector";
import AppLayout from "./components/AppLayout";
import Dashboard from "./pages/Dashboard";
import Shops from "./pages/Shops";
import ShopDetail from "./pages/ShopDetail";
import AddPurchase from "./pages/AddPurchase";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Onboarding from "./pages/Onboarding";
import SyncImport from "./pages/SyncImport";
import GalleryImport from "./pages/GalleryImport";
import NotFound from "./pages/NotFound";
import AdminPortal from "./pages/AdminPortal";

const queryClient = new QueryClient();

const LANG_CHOSEN_KEY = "khalasi_lang_chosen";

function RequireRole() {
  const role = getUserRole();
  if (!role) return <Navigate to="/onboarding" replace />;
  return <AppLayout />;
}

function PinGuard({ children }: { children: React.ReactNode }) {
  const [unlocked, setUnlocked] = useState(isSessionUnlocked());

  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === "visible" && isPinSet() && !isSessionUnlocked()) {
        setUnlocked(false);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);
    return () => document.removeEventListener("visibilitychange", handleVisibility);
  }, []);

  if (!unlocked) {
    return <PinLock onUnlock={() => setUnlocked(true)} />;
  }

  return <>{children}</>;
}

const App = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [showLangSelector, setShowLangSelector] = useState(false);

  useEffect(() => {
    const locale = getLocale();
    document.documentElement.dir = isRTL(locale) ? "rtl" : "ltr";
    document.documentElement.lang = locale;
  }, []);

  const handleSplashComplete = useCallback(() => {
    setShowSplash(false);
    // Show language selector only if user hasn't chosen yet
    if (!localStorage.getItem(LANG_CHOSEN_KEY)) {
      setShowLangSelector(true);
    }
  }, []);

  const handleLangComplete = useCallback(() => {
    localStorage.setItem(LANG_CHOSEN_KEY, "true");
    setShowLangSelector(false);
    // Re-apply direction
    const locale = getLocale();
    document.documentElement.dir = isRTL(locale) ? "rtl" : "ltr";
    document.documentElement.lang = locale;
  }, []);

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  if (showLangSelector) {
    return <LanguageSelector onComplete={handleLangComplete} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <PinGuard>
          <BrowserRouter>
            <Routes>
              <Route path="/onboarding" element={<Onboarding />} />
              <Route element={<RequireRole />}>
                <Route path="/" element={<Dashboard />} />
                <Route path="/shops" element={<Shops />} />
                <Route path="/shops/:id" element={<ShopDetail />} />
                <Route path="/add" element={<AddPurchase />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/sync" element={<SyncImport />} />
                <Route path="/import" element={<GalleryImport />} />
              </Route>
              <Route path="/khalasi-admin-portal" element={<AdminPortal />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </PinGuard>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
