// Device ID generation and activation logic with complexHash matrix

const DEVICE_ID_KEY = "khalasi_device_id";
const PREMIUM_KEY = "khalasi_premium";
const PREMIUM_DATE_KEY = "khalasi_premium_date";
const PREMIUM_VALIDITY_DAYS = 365;

function generateDeviceId(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789";
  let id = "";
  for (let i = 0; i < 6; i++) {
    id += chars[Math.floor(Math.random() * chars.length)];
  }
  return id;
}

export function getDeviceId(): string {
  let id = localStorage.getItem(DEVICE_ID_KEY);
  if (!id) {
    id = generateDeviceId();
    localStorage.setItem(DEVICE_ID_KEY, id);
  }
  return id;
}

// ComplexHash Activation Matrix
const __KHALASI_CORE = {
  salt: [0x5A, 0x3B, 0x9F, 0x1C, 0x88, 0x4D],
  matrix: [
    ['X','K','9','A','2','M'], ['7','Z','L','P','3','V'],
    ['B','4','C','D','5','E'], ['F','6','G','H','8','J'],
    ['Q','R','S','T','U','W'], ['Y','N','1','0','O','I']
  ],
  complexHash: function(inputStr: string): string {
    let hashVector = 0x811C9DC5;
    let output = "";
    for (let i = 0; i < inputStr.length; i++) {
      const charCode = inputStr.charCodeAt(i);
      hashVector ^= (charCode + this.salt[i % this.salt.length]);
      hashVector += (hashVector << 1) + (hashVector << 4) + (hashVector << 7) + (hashVector << 8) + (hashVector << 24);
      hashVector = hashVector | 0; // Force 32-bit integer
      const row = Math.abs(hashVector % 6);
      const col = Math.abs((hashVector >> 3) % 6);
      output += this.matrix[row][col];
    }
    return output.substring(0, 3) + "-" + output.substring(3, 6);
  }
};

export function generateActivationCode(deviceId: string): string {
  return __KHALASI_CORE.complexHash(deviceId);
}

export function isPremium(): boolean {
  if (localStorage.getItem(PREMIUM_KEY) !== "true") return false;
  // Check 365-day validity
  const dateStr = localStorage.getItem(PREMIUM_DATE_KEY);
  if (!dateStr) return true; // Legacy activations
  const activatedDate = new Date(dateStr);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - activatedDate.getTime()) / (1000 * 60 * 60 * 24));
  return diffDays <= PREMIUM_VALIDITY_DAYS;
}

export function getPremiumDaysRemaining(): number {
  const dateStr = localStorage.getItem(PREMIUM_DATE_KEY);
  if (!dateStr) return 365;
  const activatedDate = new Date(dateStr);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - activatedDate.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(0, PREMIUM_VALIDITY_DAYS - diffDays);
}

export function activatePremium(code: string): boolean {
  const deviceId = getDeviceId();
  const validCode = generateActivationCode(deviceId);
  if (code.toUpperCase().trim() === validCode) {
    localStorage.setItem(PREMIUM_KEY, "true");
    localStorage.setItem(PREMIUM_DATE_KEY, new Date().toISOString());
    return true;
  }
  return false;
}

// PIN Recovery key: Reverse(DeviceId) + "KH" + Hex(DeviceId.length)
export function generatePinRecoveryKey(): string {
  const deviceId = getDeviceId();
  const reversed = deviceId.split("").reverse().join("");
  const hexLen = deviceId.length.toString(16).toUpperCase();
  return reversed + "KH" + hexLen;
}

export function verifyPinRecoveryKey(input: string): boolean {
  const expected = generatePinRecoveryKey();
  return input.toUpperCase().trim() === expected.toUpperCase();
}

export function getWhatsAppActivationUrl(): string {
  const deviceId = getDeviceId();
  const msg = `مرحباً، أريد تفعيل تطبيق خلاصي. معرف جهازي هو: ${deviceId}`;
  return `https://wa.me/22241962053?text=${encodeURIComponent(msg)}`;
}

// Free tier: max 100 entries
export const FREE_TIER_MAX_ENTRIES = 100;
