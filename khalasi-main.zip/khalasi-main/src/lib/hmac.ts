// HMAC-SHA256 Anti-Fraud Digital Signature (Web Crypto API - fully offline)

const DEVICE_SECRET_KEY = "khalasi_device_secret";

async function getOrCreateDeviceSecret(): Promise<string> {
  let secret = localStorage.getItem(DEVICE_SECRET_KEY);
  if (!secret) {
    const arr = new Uint8Array(32);
    crypto.getRandomValues(arr);
    secret = Array.from(arr, b => b.toString(16).padStart(2, "0")).join("");
    localStorage.setItem(DEVICE_SECRET_KEY, secret);
  }
  return secret;
}

async function hmacSign(message: string, secret: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return Array.from(new Uint8Array(sig), b => b.toString(16).padStart(2, "0")).join("");
}

export interface SignedQRData {
  v: 2; // version
  sid: string; // shopId
  sn: string; // shopName
  txs: { id: string; amt: number; note: string; date: string; code: string }[];
  ts: string; // timestamp
  sig: string; // HMAC-SHA256 signature
}

function buildMessage(data: Omit<SignedQRData, "sig">): string {
  const txStr = data.txs.map(t => `${t.id}|${t.amt}|${t.date}`).join(";");
  return `${data.sid}|${data.sn}|${txStr}|${data.ts}`;
}

export async function createSignedQRPayload(
  shopId: string, shopName: string,
  transactions: { id: string; amount: number; note: string; date: string; verificationCode: string }[]
): Promise<string> {
  const secret = await getOrCreateDeviceSecret();
  const data: Omit<SignedQRData, "sig"> = {
    v: 2,
    sid: shopId,
    sn: shopName,
    txs: transactions.map(t => ({ id: t.id, amt: t.amount, note: t.note, date: t.date, code: t.verificationCode })),
    ts: new Date().toISOString(),
  };
  const sig = await hmacSign(buildMessage(data), secret);
  const full: SignedQRData = { ...data, sig };
  return JSON.stringify(full);
}

export async function verifySignedQRPayload(json: string, merchantSecret?: string): Promise<{ valid: boolean; data: SignedQRData | null }> {
  try {
    const data: SignedQRData = JSON.parse(json);
    if (data.v !== 2 || !data.sid || !data.txs || !data.sig) return { valid: false, data: null };
    // If we have the merchant secret we can verify; otherwise we trust the structure
    if (merchantSecret) {
      const expected = await hmacSign(buildMessage(data), merchantSecret);
      return { valid: expected === data.sig, data };
    }
    // Customer import: accept if structurally valid (signed by merchant device)
    return { valid: true, data };
  } catch {
    return { valid: false, data: null };
  }
}

export async function getDeviceSecret(): Promise<string> {
  return getOrCreateDeviceSecret();
}
