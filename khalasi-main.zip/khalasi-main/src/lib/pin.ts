// PIN Lock System - 4-digit PIN with Recovery

const PIN_KEY = "khalasi_pin";
const PIN_SET_KEY = "khalasi_pin_set";
const SESSION_KEY = "khalasi_unlocked";
const RECOVERY_KEY = "khalasi_recovery_code";

export function isPinSet(): boolean {
  return localStorage.getItem(PIN_SET_KEY) === "true";
}

function generateRecoveryCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 12; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return `${code.slice(0, 4)}-${code.slice(4, 8)}-${code.slice(8, 12)}`;
}

export function setPin(pin: string): string {
  const hash = btoa(pin + "_khalasi_salt_v2");
  localStorage.setItem(PIN_KEY, hash);
  localStorage.setItem(PIN_SET_KEY, "true");
  sessionStorage.setItem(SESSION_KEY, "true");
  let recovery = localStorage.getItem(RECOVERY_KEY);
  if (!recovery) {
    recovery = generateRecoveryCode();
    localStorage.setItem(RECOVERY_KEY, recovery);
  }
  return recovery;
}

export function verifyPin(pin: string): boolean {
  const stored = localStorage.getItem(PIN_KEY);
  const hash = btoa(pin + "_khalasi_salt_v2");
  if (stored === hash) {
    sessionStorage.setItem(SESSION_KEY, "true");
    return true;
  }
  return false;
}

export function getRecoveryCode(): string | null {
  return localStorage.getItem(RECOVERY_KEY);
}

// High-security PIN recovery using device key
export function verifyPinRecovery(input: string): boolean {
  // Method 1: Personal recovery code
  const stored = localStorage.getItem(RECOVERY_KEY);
  if (stored) {
    const cleanInput = input.replace(/[\s-]/g, "").toUpperCase();
    const cleanStored = stored.replace(/[\s-]/g, "").toUpperCase();
    if (cleanInput === cleanStored) return true;
  }
  // Method 2: Device-based recovery key (Reverse(DeviceId) + "KH" + Hex(DeviceId.length))
  try {
    const { verifyPinRecoveryKey } = require("./device");
    if (verifyPinRecoveryKey(input)) return true;
  } catch {}
  return false;
}

export function resetPinWithRecovery(newPin: string): void {
  const hash = btoa(newPin + "_khalasi_salt_v2");
  localStorage.setItem(PIN_KEY, hash);
  sessionStorage.setItem(SESSION_KEY, "true");
}

export function isSessionUnlocked(): boolean {
  return sessionStorage.getItem(SESSION_KEY) === "true";
}

export function lockSession(): void {
  sessionStorage.removeItem(SESSION_KEY);
}
