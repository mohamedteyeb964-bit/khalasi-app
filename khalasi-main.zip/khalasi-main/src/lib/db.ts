import Dexie, { type EntityTable } from "dexie";
import { obfuscate, deobfuscate, obfuscateNumber, deobfuscateNumber } from "./crypto";
import { isMerchant } from "./roles"; // تمت إضافة هذا الاستيراد للتحقق من نوع المستخدم

// Raw interfaces (stored in IndexedDB with obfuscation)
export interface ShopRecord {
  id: string;
  name_enc: string;
  createdAt: string;
  merchantPin?: string;
}

export interface PurchaseRecord {
  id: string;
  shopId: string;
  amount_enc: string;
  costPrice_enc?: string;
  note_enc: string;
  date: string;
  isPaid: boolean;
  paidAmount_enc?: string;
  verificationCode: string;
  photo?: string;
}

// Clean interfaces (used in app)
export interface Shop {
  id: string;
  name: string;
  createdAt: string;
  merchantPin?: string;
}

export interface Purchase {
  id: string;
  shopId: string;
  amount: number;
  costPrice?: number;
  note: string;
  date: string;
  isPaid: boolean;
  paidAmount?: number;
  verificationCode: string;
  photo?: string;
}

export interface BudgetRecord {
  id: string;
  monthlyLimit: number;
  month: string;
}

export interface SyncRecord {
  purchaseId: string;
  syncedAt: string;
}

class KhalasiDB extends Dexie {
  shops!: EntityTable<ShopRecord, "id">;
  purchases!: EntityTable<PurchaseRecord, "id">;
  budgets!: EntityTable<BudgetRecord, "id">;
  synced!: EntityTable<SyncRecord, "purchaseId">;

  constructor() {
    super("KhalasiDB");
    this.version(1).stores({
      shops: "id, createdAt",
      purchases: "id, shopId, date, isPaid",
      budgets: "id, month",
      synced: "purchaseId",
    });
  }
}

export const db = new KhalasiDB();

function encodeShop(shop: Shop): ShopRecord {
  return { id: shop.id, name_enc: obfuscate(shop.name), createdAt: shop.createdAt, merchantPin: shop.merchantPin };
}

function decodeShop(record: ShopRecord): Shop {
  return { id: record.id, name: deobfuscate(record.name_enc), createdAt: record.createdAt, merchantPin: record.merchantPin };
}

function encodePurchase(p: Purchase): PurchaseRecord {
  return {
    id: p.id, shopId: p.shopId, amount_enc: obfuscateNumber(p.amount),
    costPrice_enc: p.costPrice !== undefined ? obfuscateNumber(p.costPrice) : undefined,
    note_enc: obfuscate(p.note), date: p.date, isPaid: p.isPaid,
    paidAmount_enc: p.paidAmount !== undefined ? obfuscateNumber(p.paidAmount) : undefined,
    verificationCode: p.verificationCode, photo: p.photo,
  };
}

function decodePurchase(r: PurchaseRecord): Purchase {
  return {
    id: r.id, shopId: r.shopId, amount: deobfuscateNumber(r.amount_enc),
    costPrice: r.costPrice_enc ? deobfuscateNumber(r.costPrice_enc) : undefined,
    note: deobfuscate(r.note_enc), date: r.date, isPaid: r.isPaid,
    paidAmount: r.paidAmount_enc ? deobfuscateNumber(r.paidAmount_enc) : undefined,
    verificationCode: r.verificationCode, photo: r.photo,
  };
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function generateVerificationCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const digits = "0123456789";
  return chars[Math.floor(Math.random() * chars.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    digits[Math.floor(Math.random() * digits.length)];
}

function getCurrentMonth(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

// ========== SHOP OPERATIONS ==========

export async function getShops(): Promise<Shop[]> {
  const records = await db.shops.toArray();
  return records.map(decodeShop);
}

export async function addShop(name: string): Promise<Shop> {
  const shop: Shop = { id: generateId(), name, createdAt: new Date().toISOString() };
  await db.shops.add(encodeShop(shop));
  return shop;
}

export async function deleteShop(id: string): Promise<void> {
  await db.shops.delete(id);
  await db.purchases.where("shopId").equals(id).delete();
}

export async function setMerchantPin(shopId: string, pin: string): Promise<void> {
  await db.shops.update(shopId, { merchantPin: pin });
}

export async function getShopPin(shopId: string): Promise<string | undefined> {
  const record = await db.shops.get(shopId);
  return record?.merchantPin;
}

export async function verifyMerchantPin(shopId: string, pin: string): Promise<boolean> {
  const record = await db.shops.get(shopId);
  return record?.merchantPin === pin;
}

// ========== PURCHASE OPERATIONS ==========

export async function getPurchases(): Promise<Purchase[]> {
  const records = await db.purchases.toArray();
  return records.map(decodePurchase);
}

export async function getShopPurchases(shopId: string): Promise<Purchase[]> {
  const records = await db.purchases.where("shopId").equals(shopId).toArray();
  return records.map(decodePurchase);
}

export async function addPurchase(
  shopId: string, amount: number, note: string, photo?: string, costPrice?: number
): Promise<Purchase> {
  const purchase: Purchase = {
    id: generateId(), shopId, amount, costPrice, note,
    date: new Date().toISOString(), isPaid: false, paidAmount: 0,
    verificationCode: generateVerificationCode(), photo,
  };
  await db.purchases.add(encodePurchase(purchase));
  return purchase;
}

export async function deletePurchase(id: string): Promise<void> {
  await db.purchases.delete(id);
}

export async function updatePurchase(id: string, updates: Partial<Pick<Purchase, "amount" | "note">>): Promise<void> {
  const record = await db.purchases.get(id);
  if (!record) return;
  const decoded = decodePurchase(record);
  const updated = { ...decoded, ...updates };
  await db.purchases.put(encodePurchase(updated));
}

export async function makePartialPayment(purchaseId: string, payAmount: number): Promise<void> {
  const record = await db.purchases.get(purchaseId);
  if (!record) return;
  const decoded = decodePurchase(record);
  const newPaid = (decoded.paidAmount || 0) + payAmount;
  const updated = { ...decoded, paidAmount: newPaid, isPaid: newPaid >= decoded.amount };
  await db.purchases.put(encodePurchase(updated));
}

export async function settleShopDebt(shopId: string): Promise<void> {
  const records = await db.purchases.where("shopId").equals(shopId).toArray();
  for (const record of records) {
    if (!record.isPaid) {
      const decoded = decodePurchase(record);
      await db.purchases.put(encodePurchase({ ...decoded, isPaid: true, paidAmount: decoded.amount }));
    }
  }
}

// ========== AGGREGATION ==========

export async function getShopDebt(shopId: string): Promise<number> {
  const purchases = await getShopPurchases(shopId);
  return purchases.filter(p => !p.isPaid).reduce((sum, p) => sum + p.amount - (p.paidAmount || 0), 0);
}

export async function getTotalDebt(): Promise<number> {
  const purchases = await getPurchases();
  return purchases.filter(p => !p.isPaid).reduce((sum, p) => sum + p.amount - (p.paidAmount || 0), 0);
}

export async function getTotalPaid(): Promise<number> {
  const purchases = await getPurchases();
  return purchases.filter(p => p.isPaid).reduce((sum, p) => sum + p.amount, 0);
}

export async function getTotalProfit(): Promise<number> {
  const purchases = await getPurchases();
  return purchases.filter(p => p.costPrice !== undefined && p.costPrice > 0)
    .reduce((sum, p) => sum + (p.amount - (p.costPrice || 0)), 0);
}

export async function getShopProfit(shopId: string): Promise<number> {
  const purchases = await getShopPurchases(shopId);
  return purchases.filter(p => p.costPrice !== undefined && p.costPrice > 0)
    .reduce((sum, p) => sum + (p.amount - (p.costPrice || 0)), 0);
}

// ========== BUDGET ==========

export async function getBudget(): Promise<{ monthlyLimit: number; month: string }> {
  const month = getCurrentMonth();
  const record = await db.budgets.get(month);
  return record ? { monthlyLimit: record.monthlyLimit, month: record.month } : { monthlyLimit: 0, month };
}

export async function setBudget(limit: number): Promise<void> {
  const month = getCurrentMonth();
  await db.budgets.put({ id: month, monthlyLimit: limit, month });
}

export async function getMonthlySpent(): Promise<number> {
  const month = getCurrentMonth();
  const purchases = await getPurchases();
  return purchases.filter(p => p.date.startsWith(month)).reduce((sum, p) => sum + p.amount, 0);
}

export async function getDailySpending(month?: string): Promise<{ day: string; amount: number }[]> {
  const m = month || getCurrentMonth();
  const purchases = await getPurchases();
  const filtered = purchases.filter(p => p.date.startsWith(m));
  const map: Record<string, number> = {};
  filtered.forEach(p => {
    const day = new Date(p.date).getDate().toString();
    map[day] = (map[day] || 0) + p.amount;
  });
  const daysInMonth = new Date(parseInt(m.split("-")[0]), parseInt(m.split("-")[1]), 0).getDate();
  return Array.from({ length: daysInMonth }, (_, i) => ({
    day: (i + 1).toString(),
    amount: map[(i + 1).toString()] || 0,
  }));
}

// ========== SYNC ==========

export async function markPurchasesAsSynced(purchaseIds: string[]): Promise<void> {
  const now = new Date().toISOString();
  for (const id of purchaseIds) {
    await db.synced.put({ purchaseId: id, syncedAt: now });
  }
}

export async function isSynced(purchaseId: string): Promise<boolean> {
  const record = await db.synced.get(purchaseId);
  return !!record;
}

// ========== DEBT STATUS ==========

export function getPurchaseDebtStatus(p: Purchase): "unpaid" | "partial" | "paid" {
  if (p.isPaid) return "paid";
  if ((p.paidAmount || 0) > 0) return "partial";
  return "unpaid";
}

// ========== BACKUP ==========

export async function exportBackup(): Promise<string> {
  const shops = await db.shops.toArray();
  const purchases = await db.purchases.toArray();
  const budgets = await db.budgets.toArray();
  const synced = await db.synced.toArray();
  return JSON.stringify({ v: 3, shops, purchases, budgets, synced, exportDate: new Date().toISOString() });
}

export async function importBackup(json: string): Promise<boolean> {
  try {
    const data = JSON.parse(json);
    await db.transaction("rw", db.shops, db.purchases, db.budgets, db.synced, async () => {
      if (data.shops) { await db.shops.clear(); await db.shops.bulkAdd(data.shops); }
      if (data.purchases) { await db.purchases.clear(); await db.purchases.bulkAdd(data.purchases); }
      if (data.budgets) { await db.budgets.clear(); await db.budgets.bulkAdd(data.budgets); }
      if (data.synced) { await db.synced.clear(); await db.synced.bulkAdd(data.synced); }
    });
    return true;
  } catch {
    return false;
  }
}

// ========== FREEMIUM LIMITS (60/100 entries) ==========

export async function getTotalEntryCount(): Promise<number> {
  return await db.shops.count();
}

export async function getCustomerCount(): Promise<number> {
  return await db.shops.count();
}

export async function canAddMore(): Promise<boolean> {
  const { isPremium } = await import("./device");
  if (isPremium()) return true;
  
  const count = await getCustomerCount();
  // التاجر مسموح له بـ 100، والزبون مسموح له بـ 60
  const limit = isMerchant() ? 100 : 60;
  return count < limit;
}

export async function getFreemiumStatus(): Promise<{ entries: number; limitReached: boolean; max: number }> {
  const entries = await getCustomerCount();
  const { isPremium } = await import("./device");
  const max = isMerchant() ? 100 : 60;

  return {
    entries,
    limitReached: !isPremium() && entries >= max,
    max,
  };
}

// ========== ACCOUNT RECOVERY BY CODE ==========

export async function restoreAccountFromRecoveryCode(code: string): Promise<boolean> {
  // هذه الدالة جاهزة للاتصال بقاعدة بيانات سحابية لجلب البيانات عند توفر السيرفر
  try {
    if (!code || code.length < 5) return false;
    
    // محاكاة الاتصال السحابي (هنا سيتم وضع كود جلب الـ JSON من السيرفر)
    console.log("Searching for recovery code:", code);
    // return await importBackup(backupJson);
    
    return false; // نرجع false حالياً لأنه يحتاج سيرفر لاسترجاع البيانات إذا حذف التطبيق
  } catch (error) {
    console.error("Error restoring account:", error);
    return false;
  }
}
