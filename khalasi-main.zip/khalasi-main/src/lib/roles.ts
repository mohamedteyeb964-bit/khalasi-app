export type UserRole = "merchant" | "customer";

export function getUserRole(): UserRole | null {
  return localStorage.getItem("khalasi_role") as UserRole | null;
}

export function setUserRole(role: UserRole) {
  localStorage.setItem("khalasi_role", role);
}

export function isMerchant(): boolean {
  return getUserRole() === "merchant";
}

export function isCustomer(): boolean {
  return getUserRole() === "customer";
}

// Sync data interface
export interface SyncData {
  syncVersion: number;
  shopId: string;
  shopName: string;
  purchases: any[];
  exportedAt: string;
}

export function parseSyncCode(code: string): SyncData | null {
  try {
    const json = decodeURIComponent(escape(atob(code.trim())));
    const data = JSON.parse(json);
    if (data.syncVersion && data.shopId && data.purchases) return data;
    return null;
  } catch {
    return null;
  }
}
