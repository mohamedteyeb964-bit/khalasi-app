// Light obfuscation for sensitive data in IndexedDB
// NOT real encryption — just deters casual inspection

const KEY = "KhAlAsI_2026";

function xorString(str: string, key: string): string {
  let result = "";
  for (let i = 0; i < str.length; i++) {
    result += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return result;
}

export function obfuscate(text: string): string {
  try {
    return btoa(unescape(encodeURIComponent(xorString(text, KEY))));
  } catch {
    return text;
  }
}

export function deobfuscate(encoded: string): string {
  try {
    return xorString(decodeURIComponent(escape(atob(encoded))), KEY);
  } catch {
    return encoded;
  }
}

export function obfuscateNumber(n: number): string {
  return obfuscate(n.toString());
}

export function deobfuscateNumber(encoded: string): number {
  return Number(deobfuscate(encoded)) || 0;
}
