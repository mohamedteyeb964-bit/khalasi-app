export interface Shop {
  id: string;
  name: string;
  createdAt: string;
  merchantPin?: string; // PIN for edit protection
}

export interface Purchase {
  id: string;
  shopId: string;
  amount: number;
  costPrice?: number; // cost/purchase price for profit calc
  note: string;
  date: string;
  isPaid: boolean;
  paidAmount?: number; // partial payment tracking
  verificationCode: string; // e.g. "X42"
  photo?: string; // base64 data URL
}

export interface Budget {
  monthlyLimit: number;
  month: string; // "YYYY-MM"
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function generateVerificationCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const digits = "0123456789";
  const letter = chars[Math.floor(Math.random() * chars.length)];
  const d1 = digits[Math.floor(Math.random() * digits.length)];
  const d2 = digits[Math.floor(Math.random() * digits.length)];
  return `${letter}${d1}${d2}`;
}

function getCurrentMonth(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

// Shops
export function getShops(): Shop[] {
  return JSON.parse(localStorage.getItem("khalasi_shops") || "[]");
}

export function saveShops(shops: Shop[]) {
  localStorage.setItem("khalasi_shops", JSON.stringify(shops));
}

export function addShop(name: string): Shop {
  const shops = getShops();
  const shop: Shop = { id: generateId(), name, createdAt: new Date().toISOString() };
  shops.push(shop);
  saveShops(shops);
  return shop;
}

export function setMerchantPin(shopId: string, pin: string) {
  const shops = getShops().map(s => s.id === shopId ? { ...s, merchantPin: pin } : s);
  saveShops(shops);
}

export function verifyMerchantPin(shopId: string, pin: string): boolean {
  const shop = getShops().find(s => s.id === shopId);
  return shop?.merchantPin === pin;
}

export function getShopPin(shopId: string): string | undefined {
  return getShops().find(s => s.id === shopId)?.merchantPin;
}

export function deleteShop(id: string) {
  saveShops(getShops().filter((s) => s.id !== id));
  savePurchases(getPurchases().filter((p) => p.shopId !== id));
}

// Purchases
export function getPurchases(): Purchase[] {
  return JSON.parse(localStorage.getItem("khalasi_purchases") || "[]");
}

export function savePurchases(purchases: Purchase[]) {
  localStorage.setItem("khalasi_purchases", JSON.stringify(purchases));
}

export function addPurchase(shopId: string, amount: number, note: string, photo?: string, costPrice?: number): Purchase {
  const purchases = getPurchases();
  const purchase: Purchase = {
    id: generateId(),
    shopId,
    amount,
    costPrice,
    note,
    date: new Date().toISOString(),
    isPaid: false,
    paidAmount: 0,
    verificationCode: generateVerificationCode(),
    photo,
  };
  purchases.push(purchase);
  savePurchases(purchases);
  return purchase;
}

export function makePartialPayment(purchaseId: string, payAmount: number) {
  const purchases = getPurchases().map(p => {
    if (p.id !== purchaseId) return p;
    const newPaid = (p.paidAmount || 0) + payAmount;
    return { ...p, paidAmount: newPaid, isPaid: newPaid >= p.amount };
  });
  savePurchases(purchases);
}

export function getPurchaseDebtStatus(p: Purchase): "unpaid" | "partial" | "paid" {
  if (p.isPaid) return "paid";
  if ((p.paidAmount || 0) > 0) return "partial";
  return "unpaid";
}

export function getTotalPaid(): number {
  return getPurchases()
    .filter(p => p.isPaid)
    .reduce((sum, p) => sum + p.amount, 0);
}

export function getTotalProfit(): number {
  return getPurchases()
    .filter(p => p.costPrice !== undefined && p.costPrice > 0)
    .reduce((sum, p) => sum + (p.amount - (p.costPrice || 0)), 0);
}

export function getShopProfit(shopId: string): number {
  return getPurchases()
    .filter(p => p.shopId === shopId && p.costPrice !== undefined && p.costPrice > 0)
    .reduce((sum, p) => sum + (p.amount - (p.costPrice || 0)), 0);
}

export function getShopDebt(shopId: string): number {
  return getPurchases()
    .filter((p) => p.shopId === shopId && !p.isPaid)
    .reduce((sum, p) => sum + p.amount, 0);
}

export function getTotalDebt(): number {
  return getPurchases()
    .filter((p) => !p.isPaid)
    .reduce((sum, p) => sum + p.amount, 0);
}

export function settleShopDebt(shopId: string) {
  const purchases = getPurchases().map((p) =>
    p.shopId === shopId && !p.isPaid ? { ...p, isPaid: true } : p
  );
  savePurchases(purchases);
}

// Budget
export function getBudget(): Budget {
  const stored = localStorage.getItem("khalasi_budget");
  if (stored) return JSON.parse(stored);
  return { monthlyLimit: 0, month: getCurrentMonth() };
}

export function setBudget(limit: number) {
  const budget: Budget = { monthlyLimit: limit, month: getCurrentMonth() };
  localStorage.setItem("khalasi_budget", JSON.stringify(budget));
}

export function getMonthlySpent(): number {
  const month = getCurrentMonth();
  return getPurchases()
    .filter((p) => p.date.startsWith(month))
    .reduce((sum, p) => sum + p.amount, 0);
}

export function getShopPurchases(shopId: string): Purchase[] {
  return getPurchases().filter((p) => p.shopId === shopId);
}

export function deletePurchase(id: string) {
  savePurchases(getPurchases().filter((p) => p.id !== id));
}

export function updatePurchase(id: string, updates: Partial<Pick<Purchase, "amount" | "note">>) {
  const purchases = getPurchases().map((p) =>
    p.id === id ? { ...p, ...updates } : p
  );
  savePurchases(purchases);
}

export function getDailySpending(month?: string): { day: string; amount: number }[] {
  const m = month || getCurrentMonth();
  const purchases = getPurchases().filter((p) => p.date.startsWith(m));
  const map: Record<string, number> = {};
  purchases.forEach((p) => {
    const day = new Date(p.date).getDate().toString();
    map[day] = (map[day] || 0) + p.amount;
  });
  const daysInMonth = new Date(parseInt(m.split("-")[0]), parseInt(m.split("-")[1]), 0).getDate();
  return Array.from({ length: daysInMonth }, (_, i) => ({
    day: (i + 1).toString(),
    amount: map[(i + 1).toString()] || 0,
  }));
}

// License / Activation
export function isActivated(): boolean {
  return localStorage.getItem("khalasi_activated") === "true";
}

export function activateApp(code: string): boolean {
  // Accept specific codes
  const validCodes = ["KHALASI2024", "FREE50MRU", "MOBI2024", "ACTIVATE"];
  if (validCodes.includes(code.toUpperCase().trim())) {
    localStorage.setItem("khalasi_activated", "true");
    return true;
  }
  return false;
}

export function canAddMoreShops(): boolean {
  if (isActivated()) return true;
  return getShops().length < 3;
}

// Backup / Restore
export function exportBackup(): string {
  const data = {
    shops: localStorage.getItem("khalasi_shops"),
    purchases: localStorage.getItem("khalasi_purchases"),
    budget: localStorage.getItem("khalasi_budget"),
    activated: localStorage.getItem("khalasi_activated"),
    exportDate: new Date().toISOString(),
  };
  return JSON.stringify(data);
}

export function importBackup(json: string): boolean {
  try {
    const data = JSON.parse(json);
    if (data.shops) localStorage.setItem("khalasi_shops", data.shops);
    if (data.purchases) localStorage.setItem("khalasi_purchases", data.purchases);
    if (data.budget) localStorage.setItem("khalasi_budget", data.budget);
    if (data.activated) localStorage.setItem("khalasi_activated", data.activated);
    return true;
  } catch {
    return false;
  }
}
