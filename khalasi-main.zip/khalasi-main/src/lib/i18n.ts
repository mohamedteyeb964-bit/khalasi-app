// Localization system - Arabic, French, English

export type Locale = "ar" | "fr" | "en";

const LOCALE_KEY = "khalasi_locale";

export function getLocale(): Locale {
  return (localStorage.getItem(LOCALE_KEY) as Locale) || "ar";
}

export function setLocale(locale: Locale) {
  localStorage.setItem(LOCALE_KEY, locale);
}

export function isRTL(locale?: Locale): boolean {
  return (locale || getLocale()) === "ar";
}

const translations: Record<string, Record<Locale, string>> = {
  // General
  "app.name": { ar: "خلاصي", fr: "Khalasi", en: "Khalasi" },
  "app.tagline": { ar: "النظام المالي للدكان", fr: "Système financier de boutique", en: "Shop Financial System" },
  "app.loading": { ar: "جاري التحميل...", fr: "Chargement...", en: "Loading..." },
  "btn.save": { ar: "حفظ", fr: "Enregistrer", en: "Save" },
  "btn.cancel": { ar: "إلغاء", fr: "Annuler", en: "Cancel" },
  "btn.back": { ar: "رجوع", fr: "Retour", en: "Back" },
  "btn.add": { ar: "إضافة", fr: "Ajouter", en: "Add" },
  "btn.delete": { ar: "حذف", fr: "Supprimer", en: "Delete" },
  "btn.confirm": { ar: "تأكيد", fr: "Confirmer", en: "Confirm" },
  "btn.close": { ar: "إغلاق", fr: "Fermer", en: "Close" },
  "btn.edit": { ar: "تعديل", fr: "Modifier", en: "Edit" },
  "currency": { ar: "أوقية", fr: "MRU", en: "MRU" },

  // Onboarding
  "onboarding.title": { ar: "اختر طريقة استخدامك", fr: "Choisissez votre rôle", en: "Choose your role" },
  "onboarding.merchant": { ar: "أنا تاجر (صاحب محل)", fr: "Je suis commerçant", en: "I'm a Merchant" },
  "onboarding.merchant.desc": { ar: "سجّل ديون الزبائن واحمِ بياناتك برمز سري", fr: "Gérez les dettes clients avec protection PIN", en: "Manage customer debts with PIN protection" },
  "onboarding.customer": { ar: "أنا زبون (مشتري)", fr: "Je suis client", en: "I'm a Customer" },
  "onboarding.customer.desc": { ar: "تابع مشترياتك وديونك لدى المحلات", fr: "Suivez vos achats et dettes", en: "Track your purchases and debts" },
  "onboarding.continue": { ar: "متابعة", fr: "Continuer", en: "Continue" },

  // PIN
  "pin.create": { ar: "إنشاء رمز PIN", fr: "Créer un PIN", en: "Create PIN" },
  "pin.confirm": { ar: "تأكيد الرمز", fr: "Confirmer le PIN", en: "Confirm PIN" },
  "pin.enter": { ar: "أدخل رمز PIN", fr: "Entrez le PIN", en: "Enter PIN" },
  "pin.create.desc": { ar: "اختر رمزاً من 4 أرقام لحماية بياناتك", fr: "Choisissez un code à 4 chiffres", en: "Choose a 4-digit code to protect your data" },
  "pin.confirm.desc": { ar: "أعد إدخال الرمز للتأكيد", fr: "Confirmez votre code", en: "Re-enter to confirm" },
  "pin.enter.desc": { ar: "أدخل رمزك السري للمتابعة", fr: "Entrez votre code pour continuer", en: "Enter your code to continue" },
  "pin.wrong": { ar: "رمز خاطئ", fr: "Code incorrect", en: "Wrong code" },
  "pin.mismatch": { ar: "الرمز غير متطابق، حاول مجدداً", fr: "Les codes ne correspondent pas", en: "Codes don't match, try again" },
  "pin.forgot": { ar: "نسيت رمز PIN؟", fr: "PIN oublié?", en: "Forgot PIN?" },
  "pin.recovery.title": { ar: "استعادة رمز PIN", fr: "Récupérer le PIN", en: "Recover PIN" },
  "pin.recovery.enter": { ar: "أدخل كود الاسترداد", fr: "Entrez le code de récupération", en: "Enter recovery code" },
  "pin.recovery.invalid": { ar: "كود استرداد غير صحيح", fr: "Code invalide", en: "Invalid recovery code" },
  "pin.recovery.reset": { ar: "إعادة تعيين", fr: "Réinitialiser", en: "Reset" },
  "pin.security.note": { ar: "هذا الرمز سيُطلب في كل مرة تفتح التطبيق لحماية بياناتك المالية", fr: "Ce code sera demandé à chaque ouverture", en: "This code will be required each time you open the app" },

  // Navigation
  "nav.dashboard": { ar: "الرئيسية", fr: "Accueil", en: "Dashboard" },
  "nav.customers": { ar: "الزبائن", fr: "Clients", en: "Customers" },
  "nav.stores": { ar: "المحلات", fr: "Boutiques", en: "Stores" },
  "nav.add": { ar: "إضافة", fr: "Ajouter", en: "Add" },
  "nav.reports": { ar: "التقارير", fr: "Rapports", en: "Reports" },
  "nav.sync": { ar: "مزامنة", fr: "Sync", en: "Sync" },
  "nav.scan": { ar: "مسح QR", fr: "Scanner", en: "Scan QR" },
  "nav.import": { ar: "استيراد", fr: "Importer", en: "Import" },
  "nav.settings": { ar: "الإعدادات", fr: "Paramètres", en: "Settings" },
  "nav.upgrade": { ar: "ترقية", fr: "Premium", en: "Upgrade" },

  // Dashboard
  "dash.total.merchant": { ar: "إجمالي ديون الزبائن", fr: "Total des dettes clients", en: "Total Customer Debts" },
  "dash.total.customer": { ar: "إجمالي ديونك", fr: "Total de vos dettes", en: "Your Total Debts" },
  "dash.paid": { ar: "المبالغ المسددة", fr: "Montants payés", en: "Paid Amounts" },
  "dash.profit": { ar: "إجمالي الأرباح", fr: "Profits totaux", en: "Total Profits" },
  "dash.budget.title": { ar: "سقف الميزانية الشهرية", fr: "Budget mensuel", en: "Monthly Budget" },
  "dash.budget.remaining": { ar: "متبقي", fr: "restant", en: "remaining" },
  "dash.budget.over": { ar: "تجاوز!", fr: "dépassé!", en: "exceeded!" },
  "dash.budget.spent": { ar: "المصروف", fr: "Dépensé", en: "Spent" },
  "dash.budget.limit": { ar: "الحد", fr: "Limite", en: "Limit" },
  "dash.budget.placeholder": { ar: "أدخل مبلغ الميزانية...", fr: "Entrez le montant...", en: "Enter budget amount..." },
  "dash.budget.save": { ar: "حفظ الميزانية", fr: "Enregistrer le budget", en: "Save Budget" },
  "dash.chart": { ar: "النفقات اليومية", fr: "Dépenses quotidiennes", en: "Daily Expenses" },
  "dash.chart.expense": { ar: "المصروف", fr: "Dépensé", en: "Spent" },
  "dash.chart.day": { ar: "يوم", fr: "Jour", en: "Day" },
  "dash.summary.merchant": { ar: "ملخص الزبائن", fr: "Résumé clients", en: "Customers Summary" },
  "dash.summary.customer": { ar: "ملخص المحلات", fr: "Résumé boutiques", en: "Stores Summary" },
  "dash.no.debt": { ar: "لا ديون ✓", fr: "Aucune dette ✓", en: "No debts ✓" },
  "dash.no.entities.merchant": { ar: "لم تُضف أي زبائن بعد", fr: "Aucun client ajouté", en: "No customers added yet" },
  "dash.no.entities.customer": { ar: "لم تُضف أي محلات بعد", fr: "Aucune boutique ajoutée", en: "No stores added yet" },
  "dash.add.first.merchant": { ar: "أضف أول زبون ←", fr: "Ajouter un client ←", en: "Add first customer ←" },
  "dash.add.first.customer": { ar: "أضف أول محل ←", fr: "Ajouter une boutique ←", en: "Add first store ←" },
  "dash.sync.title": { ar: "مزامنة مع التاجر", fr: "Synchroniser avec le commerçant", en: "Sync with Merchant" },
  "dash.sync.desc": { ar: "امسح أو استورد QR لمطابقة الحسابات", fr: "Scanner ou importer QR", en: "Scan or import QR to match accounts" },

  // Settings
  "settings.title": { ar: "الإعدادات", fr: "Paramètres", en: "Settings" },
  "settings.role": { ar: "الدور الحالي", fr: "Rôle actuel", en: "Current Role" },
  "settings.role.merchant": { ar: "وضع التاجر", fr: "Mode commerçant", en: "Merchant Mode" },
  "settings.role.customer": { ar: "وضع الزبون", fr: "Mode client", en: "Customer Mode" },
  "settings.role.merchant.desc": { ar: "صلاحيات كتابة كاملة", fr: "Droits d'écriture complets", en: "Full write access" },
  "settings.role.customer.desc": { ar: "صلاحيات قراءة ومتابعة", fr: "Droits de lecture", en: "Read access only" },
  "settings.role.merchant.label": { ar: "تاجر", fr: "Commerçant", en: "Merchant" },
  "settings.role.customer.label": { ar: "زبون", fr: "Client", en: "Customer" },
  "settings.device": { ar: "معرف الجهاز", fr: "ID appareil", en: "Device ID" },
  "settings.language": { ar: "اللغة", fr: "Langue", en: "Language" },
  "settings.pin.change": { ar: "تغيير رمز PIN", fr: "Changer le PIN", en: "Change PIN" },
  "settings.pin.lock": { ar: "قفل التطبيق", fr: "Verrouiller", en: "Lock App" },
  "settings.backup": { ar: "النسخ الاحتياطي", fr: "Sauvegarde", en: "Backup" },
  "settings.backup.export": { ar: "تنزيل نسخة", fr: "Exporter", en: "Export Backup" },
  "settings.backup.import": { ar: "استعادة", fr: "Restaurer", en: "Restore" },
  "settings.backup.share": { ar: "مشاركة عبر واتساب", fr: "Partager via WhatsApp", en: "Share via WhatsApp" },
  "settings.backup.success": { ar: "تم استعادة البيانات بنجاح!", fr: "Données restaurées avec succès!", en: "Data restored successfully!" },
  "settings.backup.fail": { ar: "فشل في استعادة النسخة", fr: "Échec de la restauration", en: "Restore failed" },
  "settings.premium": { ar: "النسخة الكاملة", fr: "Version complète", en: "Full Version" },
  "settings.premium.status": { ar: "مفعّل", fr: "Activé", en: "Activated" },
  "settings.premium.days": { ar: "يوم متبقي", fr: "jours restants", en: "days remaining" },
  "settings.premium.expired": { ar: "منتهي الصلاحية", fr: "Expiré", en: "Expired" },
  "settings.premium.free": { ar: "مجاناً • نسخ احتياطي • استعادة", fr: "Gratuit • Sauvegarde • Restauration", en: "Free • Backup • Restore" },
  "settings.upgrade": { ar: "ترقية للنسخة الكاملة", fr: "Passer à la version complète", en: "Upgrade to Full Version" },
  "settings.recovery": { ar: "رمز الاسترداد", fr: "Code de récupération", en: "Recovery Code" },
  "settings.recovery.warn": { ar: "لا تشارك هذا الرمز مع أحد", fr: "Ne partagez pas ce code", en: "Don't share this code" },
  "settings.recovery.save": { ar: "احفظه في مكان آمن لاستعادة حسابك", fr: "Sauvegardez-le pour récupérer votre compte", en: "Save it to recover your account" },

  // Activation
  "activation.title": { ar: "ترقية النسخة الكاملة", fr: "Passer à la version complète", en: "Upgrade to Full Version" },
  "activation.desc": { ar: "افتح جميع الميزات بلا حدود", fr: "Débloquez toutes les fonctionnalités", en: "Unlock all features" },
  "activation.code.label": { ar: "أدخل كود التفعيل", fr: "Entrez le code d'activation", en: "Enter Activation Code" },
  "activation.activate": { ar: "تفعيل", fr: "Activer", en: "Activate" },
  "activation.invalid": { ar: "كود غير صحيح", fr: "Code invalide", en: "Invalid code" },
  "activation.done": { ar: "النسخة الكاملة مُفعّلة ✓", fr: "Version complète activée ✓", en: "Full version activated ✓" },
  "activation.whatsapp": { ar: "تواصل معنا عبر الواتساب", fr: "Contactez-nous via WhatsApp", en: "Contact us via WhatsApp" },
  "activation.howto": { ar: "كيف أحصل على الكود؟", fr: "Comment obtenir le code?", en: "How to get the code?" },

  // Shops/Customers
  "entity.customers": { ar: "الزبائن", fr: "Clients", en: "Customers" },
  "entity.stores": { ar: "المحلات", fr: "Boutiques", en: "Stores" },
  "entity.customer": { ar: "زبون", fr: "Client", en: "Customer" },
  "entity.store": { ar: "محل", fr: "Boutique", en: "Store" },
  "entity.add.customer": { ar: "أضف أول زبون", fr: "Ajouter un client", en: "Add first customer" },
  "entity.add.store": { ar: "أضف أول محل", fr: "Ajouter une boutique", en: "Add first store" },
  "entity.none.customer": { ar: "لم تُضف أي زبائن بعد", fr: "Aucun client ajouté", en: "No customers yet" },
  "entity.none.store": { ar: "لم تُضف أي محلات بعد", fr: "Aucune boutique ajoutée", en: "No stores yet" },
  "entity.debt": { ar: "دين", fr: "Dette", en: "Debt" },
  "entity.debt.label": { ar: "دين:", fr: "Dette:", en: "Debt:" },
  "entity.limit.near": { ar: "اقتربت من الحد الأقصى", fr: "Proche de la limite", en: "Near the limit" },
  "entity.limit.upgrade": { ar: "رقّي الآن ←", fr: "Passez au Premium ←", en: "Upgrade now ←" },
  "entity.name.placeholder.customer": { ar: "اسم الزبون (مثال: محمد)", fr: "Nom du client (ex: Mohamed)", en: "Customer name (e.g. Mohamed)" },
  "entity.name.placeholder.store": { ar: "اسم المحل (مثال: دكان أحمد)", fr: "Nom de la boutique", en: "Store name (e.g. Ahmed's Shop)" },
  "entity.delete.confirm": { ar: "حذف \"{name}\" وجميع بياناته؟", fr: "Supprimer \"{name}\" et toutes ses données?", en: "Delete \"{name}\" and all its data?" },
  "entity.add.start": { ar: "اضغط \"إضافة\" للبدء", fr: "Appuyez sur \"Ajouter\" pour commencer", en: "Press \"Add\" to start" },

  // Reports
  "reports.title": { ar: "التقارير", fr: "Rapports", en: "Reports" },
  "reports.all": { ar: "الكل", fr: "Tout", en: "All" },
  "reports.unpaid": { ar: "غير مسدد", fr: "Impayé", en: "Unpaid" },
  "reports.paid": { ar: "مسدد", fr: "Payé", en: "Paid" },
  "reports.total": { ar: "الإجمالي", fr: "Total", en: "Total" },
  "reports.transactions": { ar: "عملية", fr: "opération(s)", en: "transaction(s)" },
  "reports.due": { ar: "مستحق", fr: "Dû", en: "Due" },
  "reports.no.data": { ar: "لا توجد عمليات", fr: "Aucune opération", en: "No transactions" },
  "reports.deleted.shop": { ar: "محل محذوف", fr: "Boutique supprimée", en: "Deleted shop" },
  "reports.no.note": { ar: "بدون ملاحظة", fr: "Sans note", en: "No note" },

  // Sync
  "sync.title.merchant": { ar: "توليد كود الربط", fr: "Générer un code de liaison", en: "Generate Link Code" },
  "sync.title.customer": { ar: "استيراد كود الربط", fr: "Importer un code", en: "Import Link Code" },
  "sync.paste": { ar: "الصق كود الربط هنا...", fr: "Collez le code ici...", en: "Paste link code here..." },
  "sync.preview": { ar: "عرض البيانات", fr: "Aperçu", en: "Preview Data" },
  "sync.gallery": { ar: "من المعرض", fr: "Depuis la galerie", en: "From Gallery" },
  "sync.success": { ar: "تم المزامنة بنجاح!", fr: "Synchronisation réussie!", en: "Sync successful!" },
  "sync.imported": { ar: "تم استيراد {count} عملية جديدة وتوثيقها", fr: "{count} opérations importées", en: "{count} new transactions imported" },
  "sync.invalid.sig": { ar: "التوقيع الرقمي غير صالح — قد يكون الكود معدّلاً", fr: "Signature invalide", en: "Invalid digital signature" },
  "sync.invalid.code": { ar: "كود غير صالح", fr: "Code invalide", en: "Invalid code" },
  "sync.last.update": { ar: "آخر تحديث", fr: "Dernière mise à jour", en: "Last Updated" },
  "sync.merchant.desc": { ar: "أنشئ كوداً مشفراً لمشاركته مع الزبون", fr: "Générez un code crypté à partager", en: "Generate an encrypted code to share" },
  "sync.customer.desc": { ar: "الصق كود الربط أو استورد صورة QR", fr: "Collez le code ou importez une image QR", en: "Paste code or import a QR image" },
  "sync.signed.data": { ar: "بيانات موقعة رقمياً", fr: "Données signées numériquement", en: "Digitally signed data" },
  "sync.confirm.import": { ar: "تأكيد الاستيراد الموثق", fr: "Confirmer l'import vérifié", en: "Confirm verified import" },
  "sync.confirm.legacy": { ar: "تأكيد الاستيراد", fr: "Confirmer l'import", en: "Confirm import" },
  "sync.preview.data": { ar: "معاينة البيانات", fr: "Aperçu des données", en: "Preview data" },
  "sync.no.qr.found": { ar: "لم يتم العثور على QR Code في الصورة", fr: "Aucun QR Code trouvé dans l'image", en: "No QR Code found in the image" },
  "sync.image.error": { ar: "فشل في قراءة الصورة", fr: "Échec de lecture de l'image", en: "Failed to read the image" },
  "sync.encrypted.code": { ar: "كود الربط المشفّر", fr: "Code de liaison crypté", en: "Encrypted link code" },
  "sync.share.desc": { ar: "شارك هذا الكود أو صورة QR مع الزبون — موقّع بتشفير HMAC-SHA256", fr: "Partagez ce code — signé HMAC-SHA256", en: "Share this code — signed HMAC-SHA256" },
  "sync.copy": { ar: "نسخ", fr: "Copier", en: "Copy" },
  "sync.copied": { ar: "تم ✓", fr: "Copié ✓", en: "Copied ✓" },

  // Invoice
  "invoice.title": { ar: "فاتورة حساب", fr: "Facture", en: "Invoice" },
  "invoice.number": { ar: "رقم الفاتورة", fr: "N° facture", en: "Invoice #" },
  "invoice.settle": { ar: "تأكيد السداد", fr: "Confirmer le paiement", en: "Confirm Settlement" },
  "invoice.share": { ar: "مشاركة", fr: "Partager", en: "Share" },
  "invoice.download": { ar: "مشاركة كصورة", fr: "Partager en image", en: "Share as Image" },
  "invoice.total": { ar: "إجمالي الدين", fr: "Total de la dette", en: "Total Debt" },
  "invoice.signed": { ar: "موقّعة رقمياً (HMAC-SHA256)", fr: "Signée numériquement", en: "Digitally signed (HMAC-SHA256)" },
  "invoice.item": { ar: "الصنف", fr: "Article", en: "Item" },
  "invoice.amount": { ar: "المبلغ", fr: "Montant", en: "Amount" },
  "invoice.subtotal": { ar: "الإجمالي", fr: "Total", en: "Total" },
  "invoice.paid.amounts": { ar: "المبالغ المسددة", fr: "Montants payés", en: "Paid amounts" },
  "invoice.remaining": { ar: "إجمالي الدين", fr: "Reste à payer", en: "Remaining debt" },
  "invoice.thank.you": { ar: "شكراً لثقتكم بنا", fr: "Merci pour votre confiance", en: "Thank you for your trust" },
  "invoice.paid.label": { ar: "مدفوع", fr: "Payé", en: "Paid" },

  // Status badges
  "status.paid": { ar: "مكتملة ✓", fr: "Payée ✓", en: "Paid ✓" },
  "status.partial": { ar: "جزئي", fr: "Partiel", en: "Partial" },
  "status.unpaid": { ar: "غير مدفوعة", fr: "Impayée", en: "Unpaid" },
  "status.synced": { ar: "موثق", fr: "Vérifié", en: "Verified" },

  // Camera
  "camera.start": { ar: "تشغيل الكاميرا", fr: "Démarrer la caméra", en: "Start Camera" },
  "camera.frame.hint": { ar: "ضع الرمز داخل الإطار", fr: "Placez le code dans le cadre", en: "Place the code inside the frame" },
  "camera.no.access": { ar: "لا يمكن الوصول للكاميرا. تأكد من منح إذن الكاميرا في إعدادات المتصفح.", fr: "Impossible d'accéder à la caméra. Vérifiez les permissions.", en: "Cannot access camera. Please check browser camera permissions." },
  "camera.denied": { ar: "تم رفض إذن الكاميرا. افتح إعدادات المتصفح لتفعيله.", fr: "Permission caméra refusée. Ouvrez les paramètres du navigateur.", en: "Camera permission denied. Open browser settings to enable it." },
  "camera.attach": { ar: "التقاط أو إرفاق صورة", fr: "Capturer ou joindre une photo", en: "Capture or attach a photo" },
  "camera.attach.short": { ar: "إرفاق صورة", fr: "Joindre une photo", en: "Attach a photo" },
  "camera.compare": { ar: "تصوير سجل التاجر", fr: "Photographier le registre", en: "Photograph merchant's record" },

  // Shop Detail
  "shop.debt.summary": { ar: "عملية غير مسددة", fr: "opération(s) impayée(s)", en: "unpaid transaction(s)" },
  "shop.no.debt": { ar: "لا توجد ديون مستحقة ✓", fr: "Aucune dette ✓", en: "No debts due ✓" },
  "shop.profit": { ar: "الربح:", fr: "Profit:", en: "Profit:" },
  "shop.customer.mode": { ar: "وضع الزبون", fr: "Mode client", en: "Customer Mode" },
  "shop.invoice": { ar: "فاتورة", fr: "Facture", en: "Invoice" },
  "shop.share": { ar: "مشاركة", fr: "Partager", en: "Share" },
  "shop.pin": { ar: "الرمز", fr: "PIN", en: "PIN" },
  "shop.link": { ar: "ربط", fr: "Lier", en: "Link" },
  "shop.compare": { ar: "مقارنة", fr: "Comparer", en: "Compare" },
  "shop.quick.add": { ar: "إضافة سريعة", fr: "Ajout rapide", en: "Quick Add" },
  "shop.sell.price": { ar: "سعر البيع (أوقية)", fr: "Prix de vente (MRU)", en: "Sell price (MRU)" },
  "shop.cost.price": { ar: "سعر التكلفة (اختياري)", fr: "Prix d'achat (optionnel)", en: "Cost price (optional)" },
  "shop.note.placeholder": { ar: "ملاحظة (خبز، حليب...)", fr: "Note (pain, lait...)", en: "Note (bread, milk...)" },
  "shop.register": { ar: "تسجيل", fr: "Enregistrer", en: "Register" },
  "shop.register.success": { ar: "تم التسجيل بنجاح!", fr: "Enregistré avec succès!", en: "Registered successfully!" },
  "shop.verify.code": { ar: "كود التحقق:", fr: "Code de vérification:", en: "Verification code:" },
  "shop.search": { ar: "بحث في المشتريات...", fr: "Rechercher...", en: "Search purchases..." },
  "shop.history": { ar: "سجل المشتريات", fr: "Historique des achats", en: "Purchase History" },
  "shop.no.purchases": { ar: "لا توجد مشتريات", fr: "Aucun achat", en: "No purchases" },
  "shop.first.purchase": { ar: "سجّل أول عملية ←", fr: "Enregistrer la première ←", en: "Record first one ←" },
  "shop.payment.title": { ar: "تسديد دفعة", fr: "Effectuer un paiement", en: "Make a payment" },
  "shop.payment.amount": { ar: "المبلغ", fr: "Montant", en: "Amount" },
  "shop.payment.cash": { ar: "نقداً", fr: "Espèces", en: "Cash" },
  "shop.paid.partial": { ar: "مدفوع:", fr: "Payé:", en: "Paid:" },
  "shop.remaining": { ar: "متبقي:", fr: "Restant:", en: "Remaining:" },
  "shop.delete.confirm": { ar: "حذف هذه العملية؟", fr: "Supprimer cette opération?", en: "Delete this transaction?" },
  "shop.pin.set": { ar: "تعيين رمز", fr: "Définir un code", en: "Set code" },
  "shop.pin.change": { ar: "تغيير الرمز", fr: "Changer le code", en: "Change code" },
  "shop.pin.enter": { ar: "أدخل رمزاً سرياً", fr: "Entrez un code secret", en: "Enter a secret code" },
  "shop.pin.wrong": { ar: "رمز غير صحيح", fr: "Code incorrect", en: "Wrong code" },
  "shop.compare.title": { ar: "مقارنة الحساب", fr: "Comparer le compte", en: "Compare Account" },
  "shop.compare.desc": { ar: "صوّر سجل التاجر لمقارنته مع سجلك", fr: "Photographiez le registre pour comparer", en: "Photograph the merchant record to compare" },
  "shop.compare.records": { ar: "سجلك", fr: "Votre registre", en: "Your records" },
  "shop.compare.total": { ar: "الإجمالي", fr: "Total", en: "Total" },
  "shop.compare.more": { ar: "و {count} أخرى...", fr: "et {count} autres...", en: "and {count} more..." },

  // Add Purchase
  "add.title.merchant": { ar: "تسجيل دين على زبون", fr: "Enregistrer une dette client", en: "Record Customer Debt" },
  "add.title.customer": { ar: "تسجيل مشتريات", fr: "Enregistrer des achats", en: "Record Purchases" },
  "add.select.customer": { ar: "اختر الزبون", fr: "Choisir le client", en: "Select Customer" },
  "add.select.store": { ar: "اختر المحل", fr: "Choisir la boutique", en: "Select Store" },
  "add.sell.price": { ar: "سعر البيع (أوقية)", fr: "Prix de vente (MRU)", en: "Sell price (MRU)" },
  "add.cost.price": { ar: "سعر الشراء / التكلفة (اختياري)", fr: "Prix d'achat (optionnel)", en: "Cost price (optional)" },
  "add.profit.label": { ar: "الربح:", fr: "Profit:", en: "Profit:" },
  "add.note": { ar: "ملاحظة (اختياري)", fr: "Note (optionnel)", en: "Note (optional)" },
  "add.note.placeholder": { ar: "خبز، حليب، رصيد...", fr: "Pain, lait, crédit...", en: "Bread, milk, credit..." },
  "add.photo": { ar: "صورة (اختياري)", fr: "Photo (optionnel)", en: "Photo (optional)" },
  "add.register": { ar: "تسجيل", fr: "Enregistrer", en: "Register" },
  "add.success": { ar: "تم التسجيل بنجاح!", fr: "Enregistré avec succès!", en: "Registered successfully!" },
  "add.no.entity.merchant": { ar: "أضف زبوناً أولاً", fr: "Ajoutez un client d'abord", en: "Add a customer first" },
  "add.no.entity.customer": { ar: "أضف محلاً أولاً", fr: "Ajoutez une boutique d'abord", en: "Add a store first" },
  "add.go.customers": { ar: "الذهاب للزبائن ←", fr: "Aller aux clients ←", en: "Go to customers ←" },
  "add.go.stores": { ar: "الذهاب للمحلات ←", fr: "Aller aux boutiques ←", en: "Go to stores ←" },

  // Gallery Import
  "gallery.title": { ar: "استيراد", fr: "Importer", en: "Import" },
  "gallery.desc": { ar: "استورد صورة QR من المعرض لمطابقة الحسابات", fr: "Importez une image QR pour vérifier les comptes", en: "Import a QR image to verify accounts" },
  "gallery.select": { ar: "اختر صورة QR", fr: "Choisir une image QR", en: "Select QR Image" },
  "gallery.select.desc": { ar: "اضغط لاختيار صورة من المعرض", fr: "Appuyez pour choisir une image", en: "Tap to select an image" },

  // Backup WhatsApp
  "backup.whatsapp.title": { ar: "نسخة احتياطية — خلاصي", fr: "Sauvegarde — Khalasi", en: "Backup — Khalasi" },
  "backup.whatsapp.paste": { ar: "الصق هذه البيانات في صفحة الاستعادة:", fr: "Collez ces données dans la page de restauration:", en: "Paste this data in the restore page:" },

  // Shop Detail WhatsApp
  "shop.whatsapp.title": { ar: "كشف حساب", fr: "Relevé de compte", en: "Account Statement" },
  "shop.whatsapp.total": { ar: "الإجمالي:", fr: "Total:", en: "Total:" },
  "shop.sync.whatsapp.title": { ar: "كود ربط حساب", fr: "Code de liaison", en: "Account Link Code" },
  "shop.sync.whatsapp.desc": { ar: "الصق هذا الكود في تطبيق خلاصي > مزامنة:", fr: "Collez ce code dans Khalasi > Sync:", en: "Paste this code in Khalasi > Sync:" },
};

export function t(key: string, locale?: Locale): string {
  const l = locale || getLocale();
  return translations[key]?.[l] || translations[key]?.["ar"] || key;
}
